# tools

```
cd tools && npm install
```

Pinned dependencies: esbuild (the bundle), acorn and eslint-scope (check-layers), acorn-walk (build-uml). The browser checks use Playwright, from `PLAYWRIGHT_PATH` or a normal `require('playwright')`.

## bundle.mjs: one HTML for the production pipeline

```
node tools/bundle.mjs [--out dist/game.html]
```

It bundles `src/9-main.js` and everything it imports into one ES module (three stays external, resolved by the importmap) and inlines it into `index.html`'s module tag. It also copies `maps/` beside the output, because the page fetches the city files relative to itself (`CITY_FILE_DIR` in `1-config.js`). It fails if the bundle contains `</script`.

## pack-maps.mjs: compact hosted city files

```
node tools/pack-maps.mjs <downloadedDir> maps
```

It rewrites each saved Overpass JSON answer without whitespace and without each element's `nodes` (OSM node ids; the game reads `geometry`, never ids), and checks the result parses back to the input minus those fields. Run it on a fresh download before hosting it. Re-download if a later feature needs node ids (a road graph, say).

## checks/check-layers.mjs: the module rules

```
node tools/checks/check-layers.mjs src
```

These are errors (exit 1):

- an import from a same- or higher-numbered module, or from a relative path that isn't a src module (bare `three` and `three/...` are allowed)
- importing a name the target doesn't export
- re-exports, default exports or namespace imports between src modules
- a write to an imported binding (an `export let` another file reassigns, which would throw at runtime)
- a free name that no module declares or imports and that isn't in `KNOWN_GLOBALS`, which most likely means a missing import. `KNOWN_GLOBALS` is every global the original `game.html` used plus some common ones it didn't. Add a name there when the code starts using a new browser global.

These are notes:

- every `export let` and how often its own file writes it
- every top-level statement in files 1 to 8 that isn't a declaration, import or export. Ones that register a listener are marked `[LISTENER]`, and ones that call `wake`/`invalidate` are marked `[WAKE]` (the "files 1 to 8 declare; main starts" rule).

## checks/smoke.mjs: load the page and read the game's Debug readout

```
node tools/checks/smoke.mjs <rootDir> <page.html> [--wild] [--low] [--walk] [--zombies] [--fast] [--three <local three dir>]
```

It serves `rootDir` from a local static server and opens the page in headless Chromium (SwiftShader). It reads the Debug readout (graphics, shader programs and failed links, people, script errors) on the intro scene. Options:

- `--wild`: read it again after a wilderness load (the City switch under More World Options turned off, then Launch) and Observer, Go.
- `--zombies`: choose Zombies in the Mode row instead of Observer.
- `--walk` (with `--wild`): walk, jump and sprint on the keyboard, then read the readout again.
- `--low`: start on Graphics low.
- `--fast`: smallest Custom size, a 480x300 viewport, shorter waits, and one readout at the last stage. A run takes about 1 to 2.5 minutes.
- `--three`: serve `https://unpkg.com/three@0.160.0/...` from a local copy, for machines that can't reach unpkg.

It exits 1 on any script error, failed request, renderer crash or failed shader program. Examples: `node tools/checks/smoke.mjs . index.html --wild --low --walk --fast`, or `node tools/checks/smoke.mjs dist game.html --wild --fast` for the bundle.

Run one page at a time, because parallel runs crash the headless renderer. High graphics with `--walk` crashes SwiftShader's renderer some of the time, so use `--low` with `--walk`.

## checks/zombies.mjs: zombie behaviour through the frame loop

```
node tools/checks/zombies.mjs <rootDir> [--three <local three dir>] --part observer|killed|turned
```

It loads the smallest City-off wilderness on Graphics low (`checks/lib/game-page.mjs`), and imports the page's own `src` modules from inside the page. That gives it the same module instances the game runs, so it needs no test hooks in the game. It wraps a few methods to log what happens (contact hits, turns, matings, meals, shots, deaths) and moves bodies to set up encounters. Each test ends on a game condition, or after 3 minutes (`WAIT_LIMIT_MS` in `lib/game-page.mjs`). A test that runs out of time is reported as timed out, not passed, and the next test runs.

Parts, one page load each, all in Zombies mode (`openGame`'s `mode`):

- `observer` (the sim tests; encounters are set up away from the player):
  - the loading line's zombie count
  - infection and the 10 s turn, with the victim acting normally until then
  - converts keeping their body traits
  - a hungry zombie chasing and striking a living person
  - armed people shooting a zombie on sight
  - unarmed rule people fleeing zombies
  - zombie mating, zombie children, and the genes they inherit, plus no mixed matings
  - the hunger rule for every animal, and per tick for a lone zombie
  - broken bones and the toughness-divided chance
  - the infection rate over at least 100 rolls
  - zombie diet, coyotes ignoring zombies, and rules sampled every tick
- `killed`: in Survivor, a hungry zombie hunts the standing player until the run ends.
- `turned`: in Survivor, a zombie hits the player until one hit infects. Then every zombie is sent away and the run must end, as "Turned into a zombie", 10 s later.

When a test moves an animal it also sets `_fx` and `_fz`, so the contact search's drift stays small. Headless SwiftShader runs this world at about 2 sim ticks a second, so 10 s of sim time takes about 5 real minutes. The 10 s turn tests can time out there and need a faster machine. Run one part at a time, never in parallel with another browser check.

## checks/features.mjs: world switches, gun loot and the slot menu

```
node tools/checks/features.mjs <rootDir> [--three <local three dir>]
```

One Zombies page load (`openGame`'s `mode`), then a second in Observer. It checks:

- zombies at load, and the loading line's zombie count above 0
- every zombie then removed (health 0), so the gun, aiming and loot tests run without them
- in Zombies no person has a brain, and about `RULE_PEOPLE.armedShare` are armed
- in Observer every person has a brain and none is armed
- an armed person shoots a coyote it sees, without fleeing
- gun loot: 4,000 direct `game.loot` calls on armed bodies give the gun with 1 to 30 rounds, magazine first, with a mean matching the 5% falloff
- the slot menu through real key presses and taps: open, use, holster, drop, close
- a looted gun's rounds merging into a carried gun with no free slot
- a zombie drawn with the green-blended skin (`zombieSkinRGB`)
- about half of all people brainless, aiming at rule people (armed ones fire, unarmed ones flee), `ZOMBIES.startShare`, and the player going down at death
- a second load with Brainless people on: no brains, about half of them armed

Each test is capped at 3 minutes like `zombies.mjs`. `until` polls from the test side, because `waitForFunction`'s own timeout missed on the slow headless page.

## checks/listeners.mjs: listener order

```
node tools/checks/listeners.mjs . index.html before.txt   # before a change
node tools/checks/listeners.mjs . index.html after.txt    # after it
diff before.txt after.txt
```

It lists every event listener on `window`, `document` and the canvas after the intro loads, in registration order, with each handler's first source line. Use it when a change touches how or where listeners register.

## sound/: fitted sound models

Python 3 with numpy and scipy (matplotlib for `split_parts.py`'s spectrograms). Each sound the game plays is a model fitted to a recording; no audio ships.

```
python3 -I tools/sound/split_parts.py                                    # cut the recordings into labelled parts (edit PARTS)
python3 -I tools/sound/fit_models.py parts glock.wav sounds.json         # fit every model into sounds.json's models block
python3 -I tools/sound/export_models.py sounds.json src/1b-sound-models.js footstepWalk   # the models the game plays
```

`fit_models.py` runs from the folder holding `car.wav`, `steps.wav` and `parts/`; its tables (`BAND_MODEL_SPECS`, `ENGINE_SPEC`) say which part each model comes from. `export_models.py` writes only the named models, so add a name there when the game starts playing it. Never edit `src/1b-sound-models.js` by hand; tunables (levels, voices, distances) are `SOUND` in `src/1-config.js`.

## Not covered

Runtime behaviour beyond the readout, the in-game checklist, and TDZ order inside the modules. Modules don't load from `file://`, so open `index.html` through a static server (`npx serve` or `python3 -m http.server` from the project folder).

The one-time split tools (cut scripts, `placement.json`, the per-phase edits, `inventory.mjs`, `check-decls.mjs`) were removed once the split was done. `INVENTORY.md` records what they did, and section 9 holds the full placement.
