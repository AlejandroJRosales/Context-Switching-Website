// 7b-sim.js: SIM, artificial life and the game clock (Animal, Plant, Ecosystem, simSky). May import 1-config.js to
// 6-worlds.js, 7a-ml.js and three. Never calls render, player or main; they read its state and fill its hooks.
import * as THREE from 'three';
import {
  RUN_SPEED, STEP_UP, NPC_TICK_S, DIET_WATER_SHARE, PLANT_SIGHT_CELL, NPC_CONTACT_CELL, DEER_CRUISE, DEER_THINK_TICKS,
  DEER_SPRINT_DIST, DEER_SPRINT_OVER, DEER_SPRINT_ENERGY, NPC_SUBSTEP, DEER_EXPLORE_P, NPC_ATTACK_COOLDOWN_S,
  NPC_ATTACK_DAMAGE_PER_S, NPC_BITE_COOLDOWN_S, NPC_HIT_NO_EAT_S, PLANT_MAX_HEALTH, PLANT_BITE_NUTRITION,
  NPC_FIGHT_DAMAGE_PER_S, NPC_FIGHT_REF_STRENGTH, NPC_REF_BODY_FAT, fightMassShare, NPC_ANIMAL_FIGHT_SHARE,
  NPC_PACE_LEAN_EXP, NPC_PACE_LIMITS, bodyJumpSpeed, NPC_FIGHT_HOLD_PAD_S, NPC_FIGHT_MOVES, NIGHT_SUN_ALT_DEG,
  PREY_SIZE_STEP_KG, NPC_POUNCES, POUNCE_LAND_SHORT, FIGHT_KEY_FIELDS, NPC_AGE_DEPLETION_RATE, DEER_REPRO_SHARE,
  MATE_TIME_MULT, REPRO_NEED_MAX, NPC_MATURITY_TICKS, GROWTH_MIN_SCALE, NPC_ADULT_AGE, NPC_TICKS_PER_YEAR,
  NPC_START_AGE, TURN_RATES, HUMAN_TURN_RATE, NPC_UNIT, NPC_RADIUS, NPC_COLLIDE_H, NPC_SPAWN_GAP, NPC_SIZE, NPC_SIZE_Z_MAX,
  NPC_SIZE_HERITABILITY, NPC_REF_BMI, NPC_REF_MASS_KG, NPC_BUILD_BASE, NPC_BUILD_BASE_MEAN, NPC_WIDTH_LIMITS,
  NPC_GIRTH_STEPS, NPC_TORSO_REGIONS, NPC_BODY_SHAPE,
  NPC_SOMATOTYPES, LB_PER_KG, M_PER_IN, NPC_RATING_SPREAD, NPC_RATING_LIMITS, NPC_BODY_FAT_LIMITS, NPC_LEAN_INDEX_BASE, NPC_LEAN_REF_RATING,
  NPC_LEAN_PER_MESO, NPC_LEAN_PER_ECTO, NPC_BODY_TYPE_HERITABILITY, NPC_BODY_HERITABILITY, NPC_BODY_TRAITS, NPC_BODY_POP, SPECIES, NPC_TYPE_IDS, HUNTS_MASK,
  HUNTED_BY_MASK, NIGHT_PREY_MASK, HUNTS_LIST, WATER_SIGHT_CELL, HUMAN_FACE_VARIANTS,
  HUMAN_OUTFITS, HUMAN_SKIN, HUMAN_SHIRTS, HUMAN_PANTS, HUMAN_SUITS, CAR_GLANCE, CAR_ALIGN, FALLBACK_HOURS, SKIES,
  NPC_DRINK_SECONDS, DAY_S, NPC_HIT_ACCEL_MS2, NPC_HOLD_ACCEL_MS2, NPC_DOWN_MIN_S, NPC_DOWN_S_PER_EXCESS, NPC_DOWN_MAX_S,
  NPC_NEED_FULL, REGEN_MIN_SHARE, REGEN_COST_SHARE, NPC_FALL_S, NPC_GETUP_S, NPC_BUMP_DIST, NPC_BUMP_CONTACT_S, BUMP_RESTITUTION, BUMP_SAFE_J,
  BUMP_HEALTH_PER_J, CORPSE_S, CORPSE_MAX, GAME_START_HOUR, GAME_START_SKY, HUMAN_RIG, HUMAN_ARM_FLARE, RAGDOLL_G, RAGDOLL_DAMP, RAGDOLL_ITERS,
  RAGDOLL_FRICTION, RAGDOLL_MAX_DV, RAGDOLL_TOP_SHARE, RAGDOLL_BASE_SHARE, FALL_SETTLE_MS, FALL_SETTLE_S,
  BULLET_G, bulletDragPerM, BULLET_MAX, BULLET_GROUND_STEP_M, BULLET_DOWN_HIT_M, HIT_DAMAGE, HIT_ZONES, CARRION_MASK,
  RULE_PEOPLE, WEAPONS, PLAYER_HEIGHT, PLAYER_RADIUS, ZOMBIES, NPC_KIND_SPECS, NPC_KINDS, NPC_KIND_IDS, NPC_KIND_COUNT,
  HUMAN_KIND_ID, ZOMBIE_KIND_ID, SHOOTS_ON_SIGHT_MASK, ARMED_STANDS_MASK, NPC_GENE_START, NPC_FOOD_PER_HEALTH_TICK, BROKEN_BONE
} from './1-config.js';
import {
  cellKey, fightEase, fightClamp01, TWO_PI, wrapAngle, turnToward, SpatialGrid, ContactGrid, tools, perfProbe, sound
} from './2-core.js';
import {
  scene
} from './3-gfx-io.js';
import {
  providers, _surf, baseAt, surfaceY, surfaceFor
} from './4-provider.js';
import {
  collision, resolveCollisions, cover, occ, shellAt, isOpen, segmentHit, clipSpanY
} from './5-collision.js';
import {
  foodBoxes
} from './6-worlds.js';
import {
  brains, SpikingNetwork
} from './7a-ml.js';

// Fight state for animals and the avatar: the playing move, moveSide, and the hold (fightFrom, fightUntil).
export function startFightMove(f, move, now) {
  if (now - f.moveAt >= (f.playing ?? move).moveS) { f.moveAt = now; f.playing = move; f.moveSide = -f.moveSide; }
  if (now >= f.fightUntil) f.fightFrom = now;
  const holdS = move.flees ? move.moveS : Math.max(move.moveS, NPC_ATTACK_COOLDOWN_S + NPC_FIGHT_HOLD_PAD_S);
  f.fightUntil = Math.max(f.fightUntil, now + holdS);
}

// A person's iAct at `now`: punch reach, punching arm, guard share, unused.
export function humanFightAct(f, now, out, o) {
  const m = NPC_FIGHT_MOVES.human, u = (now - f.moveAt) / m.moveS;
  out[o] = u >= 0 && u < 1 ? (u < m.peak ? fightEase(u / m.peak) : 1 - fightEase((u - m.peak) / (1 - m.peak))) : 0;
  out[o + 1] = f.moveSide;
  out[o + 2] = fightClamp01((f.fightUntil - now) / m.guardEaseS) * fightClamp01((now - f.fightFrom) / m.guardEaseS);
  out[o + 3] = 0;
}
// KNOCKDOWNS: condition is health share x energy share.
export function conditionShare(health, maxHealth, foodNeed, waterNeed) {
  const healthShare = fightClamp01(health / maxHealth);
  const energyShare = 1 - fightClamp01(Math.max(foodNeed, waterNeed) / NPC_NEED_FULL);
  return healthShare * energyShare;
}
// REGEN, one step for any body with health, foodNeed and waterNeed (an animal, the player's game): with food and water
// both at least REGEN_MIN_SHARE full, the health bar refills at fillSharePerS (the body's drink rate, bar share per
// second) and each need bar drops REGEN_COST_SHARE of the share healed. Needs run 0 (full) to needFull (empty).
export function regenStep(body, maxHealth, needFull, fillSharePerS, dt) {
  const maxNeed = needFull * (1 - REGEN_MIN_SHARE);   // the most need that still heals
  if (body.foodNeed > maxNeed || body.waterNeed > maxNeed) return;
  const healed = Math.min(fillSharePerS * dt * maxHealth, maxHealth - body.health);   // health points
  if (!(healed > 0)) return;
  const cost = healed / maxHealth * REGEN_COST_SHARE * needFull;   // need added to each bar
  body.health += healed;
  body.foodNeed = Math.min(needFull, body.foodNeed + cost);
  body.waterNeed = Math.min(needFull, body.waterNeed + cost);
}
// Drawn knockdown share at `now`, 0 standing to 1 lying.
export function downShare(a, now) {
  if (now >= a.downUntil) return 0;
  return fightEase(fightClamp01((now - a.downAt) / NPC_FALL_S)) * fightEase(fightClamp01((a.downUntil - now) / NPC_GETUP_S));
}
// FALLS (with ragdolls on, Ecosystem.stepFalls): the physical body of a knocked-down or dead animal, stepped by the sim at
// every distance; the animal is where its body is, so the drawn body, the stats panel and the sim agree. VerletBody:
// particles, distance links, one-way hinges, ground, friction and the car's box (Ecosystem.fallBox). BoxFall and
// HumanFall lay out their rigs. The renderer poses meshes from these particles; the player's ragdoll is a HumanFall the
// renderer steps (AnimalRenderer.bodyDown).
class VerletBody {
  // n particles; links [a, b, aShare, bShare]; radii in rig units; anchors, the particles whose centre is the animal's
  // place; hinges as solveHinge. Flat typed arrays.
  constructor(n, links, radii, anchors, hinges = []) {
    this.n = n; this.radii = radii; this.anchors = anchors;
    this.nLinks = links.length;
    this.la = Int32Array.from(links, l => l[0] * 3);
    this.lb = Int32Array.from(links, l => l[1] * 3);
    this.sa = Float64Array.from(links, l => l[2]);
    this.sb = Float64Array.from(links, l => l[3]);
    this.nHinges = hinges.length;
    this.hParent = Int32Array.from(hinges, h => h[0] * 3);
    this.hJoint = Int32Array.from(hinges, h => h[1] * 3);
    this.hChild = Int32Array.from(hinges, h => h[2] * 3);
    this.hAxisFrom = Int32Array.from(hinges, h => h[3] * 3);
    this.hAxisTo = Int32Array.from(hinges, h => h[4] * 3);
    this.hMin = Float64Array.from(hinges, h => h[5]);
    this.hMax = Float64Array.from(hinges, h => h[6]);
    this.hAxis = new Float64Array(hinges.length * 3);   // last good hinge axes
    this.pos = new Float64Array(n * 3);    // particles now
    this.prev = new Float64Array(n * 3);   // last step's particles (velocity)
    this.len = new Float64Array(links.length);   // link lengths as placed
    this.floor = new Float64Array(n);      // lowest height per particle
    this.grounded = new Uint8Array(n);     // step's scratch: 1 for a particle the ground held in any pass this step
    this.kp = 0; this.ground = 0;
    this.boundX = 0; this.boundY = 0; this.boundZ = 0; this.boundR = 0;   // bounding sphere
    this.cx = 0; this.cz = 0;              // anchors' centre (anchorCentre)
  }

  // Place particle i at v, launched by (lx, lz) per step.
  place(i, v, lx, lz) {
    const o = i * 3, pos = this.pos, prev = this.prev;
    pos[o] = v.x; pos[o + 1] = v.y; pos[o + 2] = v.z;
    prev[o] = v.x - lx; prev[o + 1] = v.y; prev[o + 2] = v.z - lz;
  }

  // After place(): links keep their starting lengths. kp: metres per rig unit.
  begin(kp, ground) {
    this.kp = kp; this.ground = ground;
    for (let k = 0; k < this.nLinks; k++) this.len[k] = this.dist(this.la[k] / 3, this.lb[k] / 3);
    for (let i = 0; i < this.n; i++) this.floor[i] = ground + this.radii[i] * kp;
    // seed hinge fallback axes from the placed pose
    for (let k = 0, o = 0; k < this.nHinges; k++, o += 3) {
      const p = this.pos, a = this.hAxisFrom[k], b = this.hAxisTo[k];
      const ax = p[a] - p[b], ay = p[a + 1] - p[b + 1], az = p[a + 2] - p[b + 2], al = Math.sqrt(ax * ax + ay * ay + az * az) || 1;
      this.hAxis[o] = ax / al; this.hAxis[o + 1] = ay / al; this.hAxis[o + 2] = az / al;
    }
    this.fitBounds();
  }

  // The body's bounding sphere now, for the view cull and the box wake check.
  fitBounds() {
    const pos = this.pos, n = this.n, kp = this.kp;
    let cx = 0, cy = 0, cz = 0;
    for (let o = 0; o < n * 3; o += 3) { cx += pos[o]; cy += pos[o + 1]; cz += pos[o + 2]; }
    cx /= n; cy /= n; cz /= n;
    let rMax = 0;
    for (let i = 0, o = 0; i < n; i++, o += 3) {
      const dx = pos[o] - cx, dy = pos[o + 1] - cy, dz = pos[o + 2] - cz, r = Math.sqrt(dx * dx + dy * dy + dz * dz) + this.radii[i] * kp;
      if (r > rMax) rMax = r;
    }
    this.boundX = cx; this.boundY = cy; this.boundZ = cz; this.boundR = rMax;
  }

  dist(i, j) {
    const p = this.pos, a = i * 3, b = j * 3, dx = p[b] - p[a], dy = p[b + 1] - p[a + 1], dz = p[b + 2] - p[a + 2];
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  // One sim tick: damping, gravity, links, hinges, ground, car box.
  step(box) {
    const pos = this.pos, prev = this.prev, h = NPC_TICK_S, n3 = this.n * 3, fall = RAGDOLL_G * h * h;
    for (let o = 0; o < n3; o++) {
      const v = (pos[o] - prev[o]) * RAGDOLL_DAMP;
      prev[o] = pos[o];
      pos[o] += v;
    }
    for (let o = 1; o < n3; o += 3) pos[o] -= fall;
    const la = this.la, lb = this.lb, sa = this.sa, sb = this.sb, len = this.len, floor = this.floor, nLinks = this.nLinks;
    const grounded = this.grounded;
    grounded.fill(0);
    for (let it = 0; it < RAGDOLL_ITERS; it++) {
      for (let k = 0; k < nLinks; k++) {
        const a = la[k], b = lb[k];
        const dx = pos[b] - pos[a], dy = pos[b + 1] - pos[a + 1], dz = pos[b + 2] - pos[a + 2];
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 1e-9) continue;
        const f = (d - len[k]) / d, fa = f * sa[k], fb = f * sb[k];
        pos[a] += dx * fa; pos[a + 1] += dy * fa; pos[a + 2] += dz * fa;
        pos[b] -= dx * fb; pos[b + 1] -= dy * fb; pos[b + 2] -= dz * fb;
      }
      for (let k = 0; k < this.nHinges; k++) this.solveHinge(k);
      for (let i = 0, o = 0; i < this.n; i++, o += 3) {
        if (pos[o + 1] >= floor[i]) continue;
        pos[o + 1] = floor[i];
        grounded[i] = 1;
      }
      if (box) for (let i = 0; i < this.n; i++) this.outOfBox(i, box);
    }
    // ground friction once per step on every particle the ground held in any pass. Applied only to those still under
    // the floor in the last pass, a resting particle (left on or just above the floor by the links) slid unchecked.
    for (let i = 0, o = 0; i < this.n; i++, o += 3) {
      if (!grounded[i]) continue;
      prev[o] += (pos[o] - prev[o]) * RAGDOLL_FRICTION;
      prev[o + 2] += (pos[o + 2] - prev[o + 2]) * RAGDOLL_FRICTION;
    }
    this.fitBounds();
  }

  // The player's ragdoll only: the anchors' centre pulled toward (ax, az) at perS share per second, speed kept.
  pullToward(ax, az, perS) {
    this.anchorCentre();
    const pull = Math.min(1, perS * NPC_TICK_S);
    this.translate((ax - this.cx) * pull, (az - this.cz) * pull);
    this.fitBounds();
  }

  // Hinge k: the child segment turns from the parent's line only about the hinge axis, within [minRad, maxRad].
  // Near-parallel, the last good axis is kept.
  solveHinge(k) {
    const pos = this.pos, p = this.hParent[k], j = this.hJoint[k], c = this.hChild[k], h3 = k * 3, last = this.hAxis;
    // u: parent direction
    let ux = pos[j] - pos[p], uy = pos[j + 1] - pos[p + 1], uz = pos[j + 2] - pos[p + 2];
    const ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
    if (ul < 1e-9) return;
    ux /= ul; uy /= ul; uz /= ul;
    // A: hinge axis, or the last good one
    const f = this.hAxisFrom[k], t = this.hAxisTo[k];
    let ax = pos[f] - pos[t], ay = pos[f + 1] - pos[t + 1], az = pos[f + 2] - pos[t + 2];
    const rawLen = Math.sqrt(ax * ax + ay * ay + az * az);
    let along = ax * ux + ay * uy + az * uz;
    ax -= along * ux; ay -= along * uy; az -= along * uz;
    let al = Math.sqrt(ax * ax + ay * ay + az * az);
    const axisFromPair = al >= HUMAN_RAG_HINGE_MIN_AXIS * rawLen;   // true: the pair gives the axis
    if (!axisFromPair) {
      ax = last[h3]; ay = last[h3 + 1]; az = last[h3 + 2];
      along = ax * ux + ay * uy + az * uz;
      ax -= along * ux; ay -= along * uy; az -= along * uz;
      al = Math.sqrt(ax * ax + ay * ay + az * az);
      if (al < 1e-6) return;
    }
    ax /= al; ay /= al; az /= al;
    if (axisFromPair) { last[h3] = ax; last[h3 + 1] = ay; last[h3 + 2] = az; }
    // w = A x u
    const wx = ay * uz - az * uy, wy = az * ux - ax * uz, wz = ax * uy - ay * ux;
    // v: child segment; its angle clamped
    const vx = pos[c] - pos[j], vy = pos[c + 1] - pos[j + 1], vz = pos[c + 2] - pos[j + 2];
    const vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
    if (vl < 1e-9) return;
    const angle = Math.atan2(vx * wx + vy * wy + vz * wz, vx * ux + vy * uy + vz * uz);
    const clamped = Math.min(this.hMax[k], Math.max(this.hMin[k], angle));
    const cu = Math.cos(clamped) * vl, cw = Math.sin(clamped) * vl;
    pos[c] = pos[j] + ux * cu + wx * cw;
    pos[c + 1] = pos[j + 1] + uy * cu + wy * cw;
    pos[c + 2] = pos[j + 2] + uz * cu + wz * cw;
  }

  // Particle i out of the car's box the shallowest way, so bodies go over the car.
  outOfBox(i, box) {
    const pos = this.pos, o = i * 3, r = this.radii[i] * this.kp;
    const dx = pos[o] - box.cx, dz = pos[o + 2] - box.cz, h = pos[o + 1] - box.y;
    const u = dx * box.fx + dz * box.fz, w = dx * box.sx + dz * box.sz;   // along, across
    const penU = box.halfLen + r - Math.abs(u), penW = box.halfWid + r - Math.abs(w), penTop = box.top + r - h;
    if (penU <= 0 || penW <= 0 || penTop <= 0 || h < -r) return;
    if (penTop <= penU && penTop <= penW) pos[o + 1] += penTop;
    else if (penU <= penW) { const k = Math.sign(u) * penU; pos[o] += box.fx * k; pos[o + 2] += box.fz * k; }
    else { const k = Math.sign(w) * penW; pos[o] += box.sx * k; pos[o + 2] += box.sz * k; }
  }

  // Does the bounding sphere reach the box (Ecosystem.fallBox)? Wakes a sleeping body.
  nearBox(box) {
    const dx = this.boundX - box.cx, dz = this.boundZ - box.cz, r = this.boundR;
    return Math.abs(dx * box.fx + dz * box.fz) < box.halfLen + r && Math.abs(dx * box.sx + dz * box.sz) < box.halfWid + r &&
      this.boundY - r < box.y + box.top;
  }

  // The anchors' centre into cx, cz.
  anchorCentre() {
    const pos = this.pos, an = this.anchors;
    let cx = 0, cz = 0;
    for (let k = 0; k < an.length; k++) { cx += pos[an[k] * 3]; cz += pos[an[k] * 3 + 2]; }
    this.cx = cx / an.length; this.cz = cz / an.length;
  }

  // The body's lowest point: its lowest particle's bottom (the ground, or the roof it lies on).
  lowestY() {
    let y = Infinity;
    for (let i = 0, o = 1; i < this.n; i++, o += 3) y = Math.min(y, this.pos[o] - this.radii[i] * this.kp);
    return y;
  }

  // The largest particle move this step, squared (metres per step).
  maxStepSq() {
    const pos = this.pos, prev = this.prev;
    let m = 0;
    for (let o = 0; o < this.n * 3; o += 3) {
      const dx = pos[o] - prev[o], dy = pos[o + 1] - prev[o + 1], dz = pos[o + 2] - prev[o + 2], d2 = dx * dx + dy * dy + dz * dz;
      if (d2 > m) m = d2;
    }
    return m;
  }

  // Every particle moved by (dx, dz), its speed kept.
  translate(dx, dz) {
    const pos = this.pos, prev = this.prev;
    for (let o = 0; o < this.n * 3; o += 3) { pos[o] += dx; prev[o] += dx; pos[o + 2] += dz; prev[o + 2] += dz; }
  }

  // Speed along x and/or z stopped (a wall).
  stopAxis(x, z) {
    const pos = this.pos, prev = this.prev;
    for (let o = 0; o < this.n * 3; o += 3) { if (x) prev[o] = pos[o]; if (z) prev[o + 2] = pos[o + 2]; }
  }

  // particle i into out
  at(i, out) { const o = i * 3; return out.set(this.pos[o], this.pos[o + 1], this.pos[o + 2]); }
}

// Every fall's launch: the hit's push heading and speed (capped at RAGDOLL_MAX_DV) per step, x then z.
function fallLaunch(a) {
  const dv = Math.min(a.downDV, RAGDOLL_MAX_DV) * NPC_TICK_S;
  return [Math.sin(a.downYaw) * dv, Math.cos(a.downYaw) * dv];
}

// Each particle's world point from its rest point, placed at world / quat.
function placeFromRest(body, rest, shares, world, quat, a, v) {
  const [lx, lz] = fallLaunch(a);
  for (let i = 0; i < rest.length; i++) {
    v.copy(rest[i]).multiplyScalar(body.kp).applyQuaternion(quat).add(world);
    body.place(i, v, lx * shares[i], lz * shares[i]);
  }
}

// BOX-RIG FALLS (deer, coyotes): rear, front, top, 4 hips, 4 feet. Body and hips are rigid; feet swing. The top takes
// the full launch, so it rolls toward the push. Layouts by type in fallRigs, rig units: points, bodyR, footR (the
// renderer registers them from its meshes, AnimalRenderer.ragdollRig).
export const fallRigs = {};
const BOX_RAG_CORE = 7;   // particles 0 to 6
const BOX_RAG_LINKS = (() => {
  const links = [];
  for (let i = 0; i < BOX_RAG_CORE; i++) for (let j = i + 1; j < BOX_RAG_CORE; j++) links.push([i, j, 0.5, 0.5]);
  for (let l = 0; l < 4; l++) links.push([3 + l, 7 + l, 0, 1]);
  return links;
})();
const BOX_RAG_SHARES = [RAGDOLL_BASE_SHARE, RAGDOLL_BASE_SHARE, RAGDOLL_TOP_SHARE, ...Array(4).fill(RAGDOLL_BASE_SHARE), ...Array(4).fill(0)];
class BoxFall {
  constructor(rig) {
    this.rig = rig; this.owner = null; this.type = null; this.stillS = 0; this.asleep = false;
    this.body = new VerletBody(11, BOX_RAG_LINKS, [rig.bodyR, rig.bodyR, rig.bodyR, ...Array(8).fill(rig.footR)], [0, 1]);
    this._v = new THREE.Vector3();
  }

  // From the standing pose at world / quat on `ground`.
  start(a, world, quat, kp, ground) {
    this.body.kp = kp;
    placeFromRest(this.body, this.rig.points, BOX_RAG_SHARES, world, quat, a, this._v);
    this.body.begin(kp, ground);
  }
}

// HUMAN FALLS: pelvis, chest, head, then left/right shoulders, elbows, hands, hips, knees, feet. Torso and head are
// rigid; limbs bend on one-way hinges.
const HUMAN_RAG_CORE = [0, 1, 2, 3, 4, 9, 10];
const HUMAN_RAG_LINKS = (() => {
  const links = [];
  for (let i = 0; i < HUMAN_RAG_CORE.length; i++) for (let j = i + 1; j < HUMAN_RAG_CORE.length; j++) links.push([HUMAN_RAG_CORE[i], HUMAN_RAG_CORE[j], 0.5, 0.5]);
  // limbs: [joint, child, shares]; the end nearer the torso is heavier
  for (const s of [0, 1]) links.push([3 + s, 5 + s, 0.2, 0.8], [5 + s, 7 + s, 0.5, 0.5], [9 + s, 11 + s, 0.3, 0.7], [11 + s, 13 + s, 0.5, 0.5]);
  return links;
})();
// ELBOW AND KNEE HINGES: one way about +x, straight to flexDeg; elbow -1, knee +1.
const HUMAN_RAG_JOINT_LIMITS = {
  elbow: { flexDeg: 145, flexDir: -1 },
  knee: { flexDeg: 150, flexDir: 1 }
};
// under this axis share left, a hinge keeps its last good axis
const HUMAN_RAG_HINGE_MIN_AXIS = 0.1;
// limits [minRad, maxRad] about +x
const hingeRange = ({ flexDeg, flexDir }) => {
  const flex = flexDir * flexDeg * Math.PI / 180;
  return [Math.min(0, flex), Math.max(0, flex)];
};
// hinge rows: elbows on the shoulders' axis, knees on the hips'
const HUMAN_RAG_HINGES = (() => {
  const elbow = hingeRange(HUMAN_RAG_JOINT_LIMITS.elbow), knee = hingeRange(HUMAN_RAG_JOINT_LIMITS.knee), hinges = [];
  for (const s of [0, 1]) hinges.push([3 + s, 5 + s, 7 + s, 3, 4, ...elbow], [9 + s, 11 + s, 13 + s, 9, 10, ...knee]);
  return hinges;
})();
// ground radii, rig units
const HUMAN_RAG_RADII = [2.3, 2.3, 1.9, 1.5, 1.5, 0.9, 0.9, 0.6, 0.6, 1.8, 1.8, 1.2, 1.2, 0.9, 0.9];
// launch share per particle: the upper body leads, so it topples toward the push
const HUMAN_RAG_SHARES = [RAGDOLL_BASE_SHARE, RAGDOLL_TOP_SHARE, RAGDOLL_TOP_SHARE, RAGDOLL_TOP_SHARE, RAGDOLL_TOP_SHARE,
  0, 0, 0, 0, RAGDOLL_BASE_SHARE, RAGDOLL_BASE_SHARE, 0, 0, 0, 0];
// Rest points in rig units at body shape `shape`, matching the shader's arm and leg offsets.
function humanRagRest(shape) {
  const R = HUMAN_RIG, at = R.at;
  const arm = (s, y) => new THREE.Vector3(s * (R.shoulderX + (R.shoulder - y) * HUMAN_ARM_FLARE) * shape.shoulder, y, 0);
  const leg = (s, y) => new THREE.Vector3(s * (R.legX - (R.hip - y) * R.legSplay) * shape.hip, y, 0);
  return [new THREE.Vector3(0, R.hip, 0), new THREE.Vector3(0, at(0.84), 0), new THREE.Vector3(0, at(0.94), 0),
    arm(1, R.shoulder), arm(-1, R.shoulder), arm(1, R.elbow), arm(-1, R.elbow), arm(1, at(0.44)), arm(-1, at(0.44)),
    leg(1, R.hip), leg(-1, R.hip), leg(1, R.knee), leg(-1, R.knee), leg(1, R.ankle), leg(-1, R.ankle)];
}
export class HumanFall {
  constructor() {
    this.owner = null; this.type = null; this.stillS = 0; this.asleep = false; this.rest = null;
    this.lieReach = 0;   // the player's ragdoll: anchors' reach from the feet once lying, metres (bodyDown's pull)
    this.body = new VerletBody(15, HUMAN_RAG_LINKS, HUMAN_RAG_RADII, [0, 1], HUMAN_RAG_HINGES);
    this._v = new THREE.Vector3();
  }

  start(a, world, quat, kp, ground) {
    this.rest = humanRagRest(a.look.shape);
    this.body.kp = kp;
    const an = this.body.anchors;
    this.lieReach = an.reduce((sum, i) => sum + this.rest[i].y - HUMAN_RIG.foot, 0) / an.length * kp;
    placeFromRest(this.body, this.rest, HUMAN_RAG_SHARES, world, quat, a, this._v);
    this.body.begin(kp, ground);
  }
}

export function sampleFightKeys(keys, u, out) {
  let i = 0;
  while (i < keys.length - 2 && u > keys[i + 1].t) i++;
  const a = keys[i], b = keys[i + 1], f = fightEase(fightClamp01((u - a.t) / (b.t - a.t)));
  for (const k of FIGHT_KEY_FIELDS) out[k] = a[k] + (b[k] - a[k]) * f;
  return out;
}
// A person's BMI: the look's, or the sex's reference with no look.
function humanBmi(sex, look) {
  return look ? look.bmi : NPC_REF_BMI[sex];
}
// A person's mass in kg: BMI x height^2.
export function humanMassKg(sex, look, heightM) {
  return humanBmi(sex, look) * heightM * heightM;
}
// Fighting mass in kg: lean mass in full, fat at NPC_FAT_STRENGTH_SHARE.
export function humanFightMassKg(sex, look, heightM) {
  return humanMassKg(sex, look, heightM) * fightMassShare(look ? look.bodyFat : NPC_REF_BODY_FAT[sex]);
}
// Stats readout: age, sex, height, weight; the key packs what can change, so displays redraw only on change.
export function personInfoKey(age, sex, look, heightM) {
  const lb = Math.round(humanMassKg(sex, look, heightM) * LB_PER_KG);
  const inches = Math.round(heightM / M_PER_IN);
  return ((age + 2) * 1000 + inches) * 10000 + lb;
}
// lb packed in a personInfoKey
const personInfoLb = key => key % 10000;
// Share of lean mass counted as muscle; the readout's muscle is lean mass at this share.
const MUSCLE_SHARE_OF_LEAN = 0.5;
// type name per dominant somatotype rating
const BODY_TYPE_NAMES = { meso: 'Meso', endo: 'Endo', ecto: 'Ecto' };
// A person's body type: their highest rating's name.
function humanBodyType(look) {
  let best = null;
  for (const k in BODY_TYPE_NAMES) {
    const rating = look ? look[k] : NPC_BODY_POP[k].mean;
    if (best === null || rating > best.rating) best = { k, rating };
  }
  return BODY_TYPE_NAMES[best.k];
}
// body readout fields: fat lb, muscle lb, type name, from the same key so weights add up
export function personBodyFields(key, sex, look) {
  const lb = personInfoLb(key), fatShare = look ? look.bodyFat : NPC_REF_BODY_FAT[sex];
  return [`Fat ${Math.round(lb * fatShare)} lb`, `Muscle ${Math.round(lb * (1 - fatShare) * MUSCLE_SHARE_OF_LEAN)} lb`, humanBodyType(look)];
}
// inches as 5'9"
export const feetInches = inches => `${Math.floor(inches / 12)}'${inches % 12}"`;
// readout fields in order; each display joins them its own way
export function personInfoFields(key, sex) {
  const lb = personInfoLb(key), inches = Math.floor(key / 10000) % 1000, age = Math.floor(key / 1e7) - 2;
  return [`Age ${age < 0 ? '<' + NPC_ADULT_AGE : age}`, sex === 'male' ? 'M' : 'F', feetInches(inches), `${lb} lb`];
}

// ENTITIES

class Entity {
  constructor(position, type) {
    this.position = new THREE.Vector3(...position);
    this.type = type;
    this.mesh = null;
    this.health = 300;
    this.alive = true;
  }

  update(deltaTime) { }

  remove() {
    if (this.mesh) scene.remove(this.mesh);
  }
}

// PREY CHOICE scratch: candidates picked after the scan, once pack sums are known.
const _preyObj = [], _preyD2 = [], _preyKey = [], _preySight = [];
let _nPrey = 0;
function addPrey(obj, d2, key, sight) {
  _preyObj[_nPrey] = obj; _preyD2[_nPrey] = d2; _preyKey[_nPrey] = key; _preySight[_nPrey] = sight; _nPrey++;
}

// ENERGY: each species' reference adult mass, kg: the mean of its sexes' reference bodies at mean height
const REF_ADULT_KG = Object.fromEntries(Object.keys(SPECIES).map(t => {
  const sexes = ['male', 'female'], hOf = sex => NPC_SIZE[t][sex][0];
  const kg = sex => t === 'human' ? NPC_REF_BMI[sex] * hOf(sex) * hOf(sex) : NPC_REF_MASS_KG[t][sex];
  return [t, sexes.reduce((sum, sex) => sum + kg(sex), 0) / sexes.length];
}));

export class Animal extends Entity {
  static TWO_PI = TWO_PI;
  static DEATH_HEALTH = 1;   // health at or under which an animal dies (and leaves a corpse, Ecosystem.step)
  static FOV_H_MIN = 0.30; static FOV_H_MAX = Math.PI;
  static FOV_V_MIN = 0.08; static FOV_V_MAX = 0.60;
  static INPUT_DIMS = 19;
  static _hit = { d3sq: 0, sin: 0, cos: 0, elev: 0, dist: 0 };
  static _ray = { sin: 0, cos: 0, elev: 0, dist: 0 };

  constructor(position, type) {
    super(position, type);
    const spec = SPECIES[type];
    this.spec = spec;
    this.typeId = NPC_TYPE_IDS[type];
    // RELATION KINDS: the species' kind until a person turns (turn); relation masks read kindId, bodies read typeId
    this.kindId = NPC_KIND_IDS[type];
    this.kindSpec = NPC_KIND_SPECS[type];
    this.zombie = false;          // ZOMBIES: turned; never undone
    this.turnAt = Infinity;       // ZOMBIES: sim time an infection turns it (infect), Infinity while uninfected
    this.brokenBone = false;      // BROKEN BONES: no sprinting for life once set (rollBone)
    this.speed = spec.speed;   // the speed gene; setBodyRates must follow any write (BODY RATES)
    this.strength = NPC_GENE_START.strength;   // HERITABLE GENES; setBodyRates must follow any write
    this.WATER_SPEED_FACTOR = 0.45;
    this.submerged = false;
    this.startHealth = spec.health;   // the species' base health: meal size, bite and bullet damage, brain reward scale
    this.setToughness(NPC_GENE_START.toughness);
    this.visionDistance = tools.random(500, 2000) * NPC_UNIT;
    this.visionDistSq = this.visionDistance * this.visionDistance;

    const fh = spec.fovH, fv = spec.fovV;
    this.setFov(tools.random(fh[0], fh[1]), tools.random(fv[0], fv[1]));
    this.eyeOffset = spec.eye;

    this.generation = 0;

    this.waterNeed = Math.random() * 0.05;
    this.foodNeed = Math.random() * 0.05;
    this.reproductionNeed = Math.random() * 0.05;
    this.avoidNeed = 0;

    this.sex = Math.random() < 0.5 ? 'male' : 'female';
    this.setSizeZ(tools.gauss());
    this.look = type === 'human' ? humanLook(this.sex) : null;   // appearance (render only), for life
    this.waterIncrement = this.startHealth * 0.000001;
    this.ageDepl = this.startHealth * NPC_AGE_DEPLETION_RATE;
    this.setBodyRates();
    // the species' pounce (NPC_POUNCES), undefined for species that do not pounce; the type never changes
    this.pounceSpec = NPC_POUNCES[type];
    this.mutationMulti = 0.5;
    this.lastChildTime = ecosystem.time;   // sim seconds
    this.childGracePeriod = (15 + Math.random() * 15) * spec.grace * MATE_TIME_MULT;   // sim seconds
    this.lookForMate = false;

    this.memPredatorX = 0; this.memPredatorY = 0; this.memPredatorZ = 0; this.hasPredator = false;
    this.memFoodX = 0; this.memFoodY = 0; this.memFoodZ = 0; this.hasFood = false;
    this.memWaterX = 0; this.memWaterY = 0; this.memWaterZ = 0; this.hasWater = false;
    this.memMateX = 0; this.memMateY = 0; this.memMateZ = 0; this.hasMate = false;
    this.priority = null;          // deer focus: 'predator', 'fight', 'hunt', 'loot', 'food', 'water', 'mate', or null exploring
    this.speedScale = 1;
    this.sprinting = false;
    this.nextAttackAt = 0;   // next attack time
    this.nextBiteAt = 0;     // next bite time
    this.noEatUntil = 0;     // no eating until then after a hit
    // fight move and hold; no steps while ecosystem.time < fightUntil
    this.moveAt = -Infinity; this.playing = null; this.moveSide = 1; this.fightFrom = 0; this.fightUntil = 0;
    // KNOCKDOWNS: downAt starts the fall, downUntil ends the hold; downYaw, downDV for render
    this.downAt = -Infinity; this.downUntil = 0; this.downYaw = 0; this.downDV = 0;
    this.contactTick = -Infinity;   // BUMP IMPACTS: last tick the player or the car touched it (Ecosystem.freshContact)
    this.fall = null;               // FALLS: its body while knocked down or dead with ragdolls on (Ecosystem.beginFall)
    this.corpseUntil = 0;           // CORPSES: sim time its body goes (Ecosystem.addCorpse)
    this.diedAt = 0;                // CORPSES: sim time it died; its readouts stop here
    this.quarry = null;      // night hunt quarry (animal or avatar)
    // PACK STRENGTH: mass and height summed over the pack in sight
    this.packMassKg = 0; this.packHeightM = 0;
    this.pounceAt = -Infinity;   // start of the current or last pounce
    this.nextPounceAt = 0;       // next pounce time
    this.fleeFrom = null;    // who a fleeing species' move answered
    this.fleeUntil = 0;      // no new flee move until then
    this.bumpScale = 1;

    // no target reads as distance 1 (sight's edge), never 0 (touching)
    this.rayFoodSin = 0; this.rayFoodCos = 0; this.rayFoodElev = 0; this.rayFoodDist = 1;
    this.rayWaterSin = 0; this.rayWaterCos = 0; this.rayWaterElev = 0; this.rayWaterDist = 1;
    this.rayPredatorSin = 0; this.rayPredatorCos = 0; this.rayPredatorElev = 0; this.rayPredatorDist = 1;
    this.rayMateSin = 0; this.rayMateCos = 0; this.rayMateElev = 0; this.rayMateDist = 1;

    // PEOPLE WITHOUT BRAINS (RULE_PEOPLE): one roll splits people into a zombie slice, an armed brainless slice, and the
    // rest: brained in Observer, unarmed brainless in Zombies (provider.opts.brainless)
    const human = type === 'human';
    const zombieShare = ecosystem.seedingZombies ? RULE_PEOPLE.zombieShare : 0;   // only at world load in Zombies mode
    const armedShare = ecosystem.armedOn ? RULE_PEOPLE.armedShare : 0;            // only where the mode arms people (PLAY_MODES.armed)
    const roll = human ? Math.random() : 1;   // 1 for every other species: in no slice
    this.seedZombie = roll < zombieShare;                                         // true: no brain, no gun, turned by startOutbreak
    const armed = !this.seedZombie && roll < zombieShare + armedShare;            // true: no brain, a gun
    const ruled = human && (this.seedZombie || armed || ecosystem.brainlessOn);    // true: no brain, the rule AI
    this.brain = spec.brain && !ruled ? new SpikingNetwork(Animal.INPUT_DIMS) : null;
    this.ACTION_HOLD = this.brain ? 60 : DEER_THINK_TICKS;
    this.gun = armed ? WEAPONS[RULE_PEOPLE.weapon] : null;   // endless rounds
    // TURNING: rad/s toward targetHeading (TURN_RATES; a brain turns at HUMAN_TURN_RATE); Infinity turns at once
    this.turnRate = TURN_RATES[type] ?? (this.brain ? HUMAN_TURN_RATE : Infinity);
    // ARMED: aim error each way, radians (MARKSMANSHIP: half its group, groupMOA); 0 unarmed
    const [hunterMOA, averageMOA] = RULE_PEOPLE.groupMOA;
    this.aimErrorRad = armed ? (hunterMOA + Math.random() * (averageMOA - hunterMOA)) / 2 * Math.PI / (180 * 60) : 0;
    this.looter = armed && Math.random() < RULE_PEOPLE.looterShare;   // ARMED: shoots a Survivor player, then stands over the body
    this.lootMark = null;                               // LOOTER: the player it has shot at (its body is the loot), or null
    this.setFood(ruled ? RULE_PEOPLE.food : spec.food);
    this.prey = null;                                   // the rule AI's food pick in sight (searchDeer), or null
    this.onSight = null;                                // ARMED: nearest in-sight body of a kind it shoots on sight, or null
    this.foe = null; this.foeUntil = 0;                 // ARMED: the last attacker and until when it is a target
    this.avoidPlayerUntil = 0;                          // UNARMED: sim time until which a Survivor player who aimed at it is a threat
    this.lastShotAt = -Infinity;                        // ARMED: sim time of its last shot (drawn aim)
    this.nextShotAt = 0;                                // ARMED: sim time it may fire again (fire cadence, RULE_PEOPLE)
    this.pairShotDue = false;                           // ARMED: true while the second shot of a pair is pending
    this.actionTimer = Math.floor(Math.random() * this.ACTION_HOLD);
    // City: heading in radians; people turn toward targetHeading.
    this.heading = Math.random() * Animal.TWO_PI;
    this.targetHeading = this.heading;
    // headingDir's memo: sin and cos of heading as of _dirFor (NaN: none yet)
    this._dirFor = NaN; this._dirSin = 0; this._dirCos = 1;
    this.moving = true;
    this.facingAngle = this.heading;
    this.prevHealth = this.health;
    this.prevWaterNeed = this.waterNeed;
    this.prevFoodNeed = this.foodNeed;
    this._inputs = new Float32Array(Animal.INPUT_DIMS);

    this.isAdult = true;
    this.birthTick = 0;
    // age in years at ageBaseTick
    this.ageBaseTick = ecosystem.ticks;
    this.ageBase = NPC_START_AGE[0] + Math.random() * (NPC_START_AGE[1] - NPC_START_AGE[0]);

    this.animTime = Math.random() * Math.PI * 2;
    // people's gait (render only)
    this.gaitPhase = Math.random() * Animal.TWO_PI;
    this.gaitSwing = 0; this.gaitRun = 0; this.gaitSpeed = 0;
    this.gaitX = NaN; this.gaitZ = NaN;

    this.focusX = this.position.x;
    this.focusZ = this.position.z;
    this.tob = ecosystem.time;   // birth time, sim seconds

    this._hx = NaN; this._hz = NaN; this._hv = -1; this._h = 0;

    // City: last wall-clear position, Ecosystem.collide's fallback
    this.freeX = this.position.x; this.freeZ = this.position.z;
    this._fx = NaN; this._fz = NaN;

    this.mesh = null;
    this.home = null;
    this._gk = -1;   // animalGrid bucket, -1 when not filed
  }

  remove() { }

  setFov(h, v) {
    this.fovH = tools.clamp(h, Animal.FOV_H_MIN, Animal.FOV_H_MAX);
    this.fovV = tools.clamp(v, Animal.FOV_V_MIN, Animal.FOV_V_MAX);
    this.cosFovH = Math.cos(this.fovH);
    this.tanFovV = Math.tan(this.fovV);
  }

  // City: body-centre height above the feet in Arena units.
  footLift() {
    const hs = this.heightScale;
    return this.spec.lift * hs;
  }

  eyeY() {
    return this.position.y + this.eyeOffset * this.heightScale * NPC_UNIT;
  }

  // Is (tx, ty, tz) in the vision cone, in sight and nearer than `beat` (squared 3D distance)? A target at or past
  // `beat` cannot replace the current best under locate's strict `<`, so it is rejected before the cone and the
  // line-of-sight test; the targets locate picks are the same as testing everything.
  senseCloser(px, py, pz, ax, az, cosH, tanV, tx, ty, tz, beat) {
    const dx = tx - px, dy = ty - py, dz = tz - pz;
    const h2 = dx * dx + dz * dz;
    if (h2 === 0) return false;
    const d3sq = h2 + dy * dy;
    if (!(d3sq < beat)) return false;
    if (d3sq > this.visionDistSq) return false;
    const h = Math.sqrt(h2);
    if ((dx * ax + dz * az) < cosH * h) return false;
    if (Math.abs(dy) > tanV * h) return false;
    if (cover.blocks(px, py, pz, tx, ty, tz)) return false;
    const d3 = Math.sqrt(d3sq);
    const hit = Animal._hit;
    hit.d3sq = d3sq;
    hit.sin = dx / h;
    hit.cos = dz / h;
    hit.elev = dy / d3;
    hit.dist = Math.min(1, d3 / this.visionDistance);
    return true;
  }

  outOfRange(mx, my, mz) {
    const dx = mx - this.position.x;
    const dy = my - this.eyeY();
    const dz = mz - this.position.z;
    return (dx * dx + dy * dy + dz * dz) > this.visionDistSq;
  }

  // Brained senses: food, predators, mates and water in the vision cone.
  locate(grid) {
    const px = this.position.x, pz = this.position.z;
    const py = this.eyeY();
    const vd = this.visionDistSq;
    const ax = Math.sin(this.facingAngle), az = Math.cos(this.facingAngle);
    const cosH = this.cosFovH, tanV = this.tanFovV;
    const hit = Animal._hit;
    const type = this.type, tid = this.kindId;
    const huntedBy = HUNTED_BY_MASK[tid], hunts = HUNTS_MASK[tid];
    let bestPredDist = Infinity, bestFoodDist = Infinity, bestMateDist = Infinity, bestWaterDist = Infinity;

    // Animals in the grid cells covering the sight circle, in the grid's visit order; the distance reject matches
    // senseCloser's.
    const r = this.visionDistance;
    const seen = ecosystem._qSeen;
    const nSeen = grid.queryInto(seen, px, pz, r);
    for (let _i = 0; _i < nSeen; _i++) {
      const obj = seen[_i];
      if (obj === this) continue;
      const ox = obj.position.x, oy = obj.position.y, oz = obj.position.z;
      const hx = ox - px, hz = oz - pz;
      if (hx * hx + hz * hz > vd) continue;
      const oid = obj.kindId, obit = 1 << oid;
      const isPred = (huntedBy & obit) !== 0;
      const isFood = (hunts & obit) !== 0;
      const isMate = oid === tid && this.sex !== obj.sex;
      if (!isPred && !isFood && !isMate) continue;
      // the farthest best among the categories obj could fill: nearer than this, it can replace at least one of them;
      // at or past it, it can replace none (each category below still checks its own best)
      const beat = Math.max(isPred ? bestPredDist : 0, isFood ? bestFoodDist : 0, isMate ? bestMateDist : 0);
      if (!this.senseCloser(px, py, pz, ax, az, cosH, tanV, ox, oy, oz, beat)) continue;

      if (isPred) {
        if (hit.d3sq < bestPredDist) {
          bestPredDist = hit.d3sq;
          this.memPredatorX = ox; this.memPredatorY = oy; this.memPredatorZ = oz;
          this.hasPredator = true;
          this.rayPredatorSin = hit.sin; this.rayPredatorCos = hit.cos;
          this.rayPredatorElev = hit.elev; this.rayPredatorDist = hit.dist;
        }
      }
      if (isFood) {
        if (hit.d3sq < bestFoodDist) {
          bestFoodDist = hit.d3sq;
          this.memFoodX = ox; this.memFoodY = oy; this.memFoodZ = oz;
          this.hasFood = true;
          this.rayFoodSin = hit.sin; this.rayFoodCos = hit.cos;
          this.rayFoodElev = hit.elev; this.rayFoodDist = hit.dist;
        }
      }
      if (isMate) {
        if (hit.d3sq < bestMateDist) {
          bestMateDist = hit.d3sq;
          this.memMateX = ox; this.memMateY = oy; this.memMateZ = oz;
          this.hasMate = true;
          this.rayMateSin = hit.sin; this.rayMateCos = hit.cos;
          this.rayMateElev = hit.elev; this.rayMateDist = hit.dist;
        }
      }
    }

    // City: in Survivor the player is a predator to what people hunt
    const gp = ecosystem.avatar;
    if (gp.isThreatTo(tid) &&
      this.senseCloser(px, py, pz, ax, az, cosH, tanV, gp.position.x, gp.position.y, gp.position.z, bestPredDist)) {
      bestPredDist = hit.d3sq;
      this.memPredatorX = gp.position.x; this.memPredatorY = gp.position.y; this.memPredatorZ = gp.position.z;
      this.hasPredator = true;
      this.rayPredatorSin = hit.sin; this.rayPredatorCos = hit.cos;
      this.rayPredatorElev = hit.elev; this.rayPredatorDist = hit.dist;
    }

    // City: plants are food for people too, from the sight grid.
    const seenPlants = ecosystem._qSeenPlants;
    const nPlants = ecosystem.plantSight.queryInto(seenPlants, px, pz, r);
    for (let _i = 0; _i < nPlants; _i++) {
      const plant = seenPlants[_i];
      if (!plant.alive) continue;
      const qx = plant.position.x - px, qz = plant.position.z - pz;
      if (qx * qx + qz * qz > vd) continue;
      if (!this.senseCloser(px, py, pz, ax, az, cosH, tanV,
        plant.position.x, plant.position.y, plant.position.z, bestFoodDist)) continue;
      bestFoodDist = hit.d3sq;
      this.memFoodX = plant.position.x; this.memFoodY = plant.position.y; this.memFoodZ = plant.position.z;
      this.hasFood = true;
      this.rayFoodSin = hit.sin; this.rayFoodCos = hit.cos;
      this.rayFoodElev = hit.elev; this.rayFoodDist = hit.dist;
    }

    // food boxes are food for people: nearest of animal, plant and crate wins
    if (type === 'human' && foodBoxes.list.length) {
      const nBox = foodBoxes.sight.queryInto(ecosystem._qBox, px, pz, this.visionDistance);
      for (let _i = 0; _i < nBox; _i++) {
        const bp = ecosystem._qBox[_i].position;
        if (!this.senseCloser(px, py, pz, ax, az, cosH, tanV, bp.x, bp.y, bp.z, bestFoodDist)) continue;
        bestFoodDist = hit.d3sq;
        this.memFoodX = bp.x; this.memFoodY = bp.y; this.memFoodZ = bp.z;
        this.hasFood = true;
        this.rayFoodSin = hit.sin; this.rayFoodCos = hit.cos;
        this.rayFoodElev = hit.elev; this.rayFoodDist = hit.dist;
      }
    }

    // water, from the sight grid
    const nWater = ecosystem.waterSight.queryInto(ecosystem._qWater, px, pz, this.visionDistance);
    for (let _i = 0; _i < nWater; _i++) {
      const wp = ecosystem._qWater[_i].position;
      const qx = wp.x - px, qz = wp.z - pz;
      if (qx * qx + qz * qz > vd) continue;
      if (!this.senseCloser(px, py, pz, ax, az, cosH, tanV, wp.x, wp.y, wp.z, bestWaterDist)) continue;
      bestWaterDist = hit.d3sq;
      this.memWaterX = wp.x; this.memWaterY = wp.y; this.memWaterZ = wp.z;
      this.hasWater = true;
      this.rayWaterSin = hit.sin; this.rayWaterCos = hit.cos;
      this.rayWaterElev = hit.elev; this.rayWaterDist = hit.dist;
    }

    if (this.hasPredator && this.outOfRange(this.memPredatorX, this.memPredatorY, this.memPredatorZ)) {
      this.hasPredator = false;
      this.rayPredatorSin = 0; this.rayPredatorCos = 0;
      this.rayPredatorElev = 0; this.rayPredatorDist = 1;
    }
    if (this.hasFood && this.outOfRange(this.memFoodX, this.memFoodY, this.memFoodZ)) {
      this.hasFood = false;
      this.rayFoodSin = 0; this.rayFoodCos = 0;
      this.rayFoodElev = 0; this.rayFoodDist = 1;
    }
    if (this.hasWater && this.outOfRange(this.memWaterX, this.memWaterY, this.memWaterZ)) {
      this.hasWater = false;
      this.rayWaterSin = 0; this.rayWaterCos = 0;
      this.rayWaterElev = 0; this.rayWaterDist = 1;
    }
    if (this.hasMate && this.outOfRange(this.memMateX, this.memMateY, this.memMateZ)) {
      this.hasMate = false;
      this.rayMateSin = 0; this.rayMateCos = 0;
      this.rayMateElev = 0; this.rayMateDist = 1;
    }
    this.refreshRays();
  }

  // Remembered targets point from the current eye to the remembered spot.
  refreshRays() {
    const px = this.position.x, py = this.eyeY(), pz = this.position.z, vd = this.visionDistance;
    const ray = (mx, my, mz) => {
      const dx = mx - px, dy = my - py, dz = mz - pz;
      const h = Math.hypot(dx, dz), d3 = Math.hypot(h, dy);
      const r = Animal._ray;
      if (h === 0) { r.sin = 0; r.cos = 0; } else { r.sin = dx / h; r.cos = dz / h; }
      r.elev = d3 === 0 ? 0 : dy / d3;
      r.dist = Math.min(1, d3 / vd);
      return r;
    };
    let r;
    if (this.hasFood) {
      r = ray(this.memFoodX, this.memFoodY, this.memFoodZ);
      this.rayFoodSin = r.sin; this.rayFoodCos = r.cos; this.rayFoodElev = r.elev; this.rayFoodDist = r.dist;
    }
    if (this.hasWater) {
      r = ray(this.memWaterX, this.memWaterY, this.memWaterZ);
      this.rayWaterSin = r.sin; this.rayWaterCos = r.cos; this.rayWaterElev = r.elev; this.rayWaterDist = r.dist;
    }
    if (this.hasPredator) {
      r = ray(this.memPredatorX, this.memPredatorY, this.memPredatorZ);
      this.rayPredatorSin = r.sin; this.rayPredatorCos = r.cos;
      this.rayPredatorElev = r.elev; this.rayPredatorDist = r.dist;
    }
    if (this.hasMate) {
      r = ray(this.memMateX, this.memMateY, this.memMateZ);
      this.rayMateSin = r.sin; this.rayMateCos = r.cos; this.rayMateElev = r.elev; this.rayMateDist = r.dist;
    }
  }

  // Refreshes _dirSin and _dirCos to the current heading (Math.sin and Math.cos, recomputed only when heading changed).
  headingDir() {
    const h = this.heading;
    // a new heading, or 0 after -0 (or back): Math.sin keeps the zero's sign, so the memo does too
    if (h !== this._dirFor || (h === 0 && 1 / h !== 1 / this._dirFor)) {
      this._dirFor = h; this._dirSin = Math.sin(h); this._dirCos = Math.cos(h);
    }
  }

  // World (sin, cos) in the body's frame: (0, 1) ahead, sin > 0 right.
  static egoSin(s, c, fs, fc) { return s * fc - c * fs; }
  static egoCos(s, c, fs, fc) { return c * fc + s * fs; }

  think(grid) {
    this.locate(grid);
    const inp = this._inputs;

    // relative to facing, so directions mean the same whichever way the body points
    const fs = Math.sin(this.facingAngle), fc = Math.cos(this.facingAngle);
    const es = Animal.egoSin, ec = Animal.egoCos;
    inp[0] = es(this.rayFoodSin, this.rayFoodCos, fs, fc);
    inp[1] = ec(this.rayFoodSin, this.rayFoodCos, fs, fc);
    inp[2] = this.rayFoodElev;
    inp[3] = this.rayFoodDist;
    inp[4] = es(this.rayWaterSin, this.rayWaterCos, fs, fc);
    inp[5] = ec(this.rayWaterSin, this.rayWaterCos, fs, fc);
    inp[6] = this.rayWaterElev;
    inp[7] = this.rayWaterDist;
    inp[8] = es(this.rayPredatorSin, this.rayPredatorCos, fs, fc);
    inp[9] = ec(this.rayPredatorSin, this.rayPredatorCos, fs, fc);
    inp[10] = this.rayPredatorElev;
    inp[11] = this.rayPredatorDist;
    inp[12] = es(this.rayMateSin, this.rayMateCos, fs, fc);
    inp[13] = ec(this.rayMateSin, this.rayMateCos, fs, fc);
    inp[14] = this.rayMateElev;
    inp[15] = this.rayMateDist;
    inp[16] = this.foodNeed < 100 ? this.foodNeed / 100 : 1;
    inp[17] = this.waterNeed < 100 ? this.waterNeed / 100 : 1;
    inp[18] = this.health / this.maxHealth;

    this.targetHeading = wrapAngle(this.facingAngle + this.brain.think(inp));
    this.moving = true;
  }

  // DEER AND COYOTE AI (species.py): thinkDeer picks the top need; steerDeer moves every tick.
  thinkDeer(grid) {
    if (Math.random() <= 1 - Math.pow(1 - DEER_EXPLORE_P, DEER_THINK_TICKS)) this.newExploreCoords();
    this.searchDeer(grid);

    let best = null, bestV = -Infinity;
    if (this.hasPredator && this.avoidNeed > bestV) { best = 'predator'; bestV = this.avoidNeed; }
    // a night hunt outranks all but fleeing
    if (this.quarry !== null && best === null) { best = 'hunt'; bestV = Infinity; }
    if (this.hasFood && this.foodNeed > bestV) { best = 'food'; bestV = this.foodNeed; }
    if (this.hasWater && this.waterNeed > bestV) { best = 'water'; bestV = this.waterNeed; }
    if (this.hasMate && this.reproductionNeed > bestV) { best = 'mate'; bestV = this.reproductionNeed; }
    // LOOTER: once the player it shot lies dead, its body comes before everything but fleeing
    if (best !== 'predator' && this.looting()) best = 'loot';
    // FIGHT (armed): a foe, a looter's live player or a kind it shoots on sight comes before all but fleeing; it stands
    // and turns to face it (steerFight) while shootStep fires. Prey is shot within the food goal instead.
    if (best !== 'predator' && this.gun !== null && this.fightTarget(ecosystem.time) !== null) best = 'fight';
    this.priority = best;

    const x = this.position.x, z = this.position.z;
    if (best === 'predator') {
      const ax = x - this.memPredatorX, az = z - this.memPredatorZ;
      if (ax !== 0 || az !== 0) this.headTo(wrapAngle(Math.atan2(ax, az)));
    } else if (best === 'hunt') { this.focusX = this.quarry.position.x; this.focusZ = this.quarry.position.z; }
    else if (best === 'loot') { this.focusX = this.lootMark.position.x; this.focusZ = this.lootMark.position.z; }
    else if (best === 'food') { this.focusX = this.memFoodX; this.focusZ = this.memFoodZ; }
    else if (best === 'water') { this.focusX = this.memWaterX; this.focusZ = this.memWaterZ; }
    else if (best === 'mate') { this.focusX = this.memMateX; this.focusZ = this.memMateZ; }

    const fx = this.memPredatorX - x, fz = this.memPredatorZ - z;
    const fighting = best === 'fight';   // true: stands its ground, facing the target (steerFight)
    const chase = best === 'hunt' || best === 'loot' || (best === 'food' && this.food !== 'plant');
    this.sprinting = chase || (best === 'predator' && fx * fx + fz * fz <= DEER_SPRINT_DIST * DEER_SPRINT_DIST);
    this.speedScale = best === 'predator' ? 1 : DEER_CRUISE;
    this.bumpScale = 1;
    if (best !== 'predator' && !fighting) this.aimAtFocus();
    this.moving = !fighting;
  }

  aimAtFocus() {
    const dx = this.focusX - this.position.x, dz = this.focusZ - this.position.z;
    if (dx !== 0 || dz !== 0) this.headTo(wrapAngle(Math.atan2(dx, dz)));
  }

  // TURNING: a new heading goal; move turns to it at turnRate (an Infinity rate takes it at once).
  headTo(angle) {
    this.targetHeading = angle;
    if (this.turnRate === Infinity) this.heading = angle;
  }

  // FIGHT: face the target while it lasts; once it is gone, decide again next tick.
  steerFight() {
    const t = this.fightTarget(ecosystem.time);
    if (t === null) { this.priority = null; this.actionTimer = 0; return; }
    this.headToward(t.position.x, t.position.z, 1);
  }

  steerDeer() {
    // sprinting burns DEER_SPRINT_ENERGY x walking energy
    if (this.runs()) this.foodNeed += this.foodIncrement * (DEER_SPRINT_ENERGY - 1);

    if (this.priority === 'hunt') { this.steerHunt(); return; }
    if (this.priority === 'loot') { this.steerLoot(); return; }
    if (this.priority === 'fight') { this.steerFight(); return; }
    // the heading holds until the next decision; only arrival is checked
    if (this.priority === 'predator' || !this.moving) return;
    const dx = this.focusX - this.position.x, dz = this.focusZ - this.position.z;
    const step = this.stepLength();
    if (dx * dx + dz * dz <= step * step) {
      // at the focus: stand; a reached explore point is replaced
      if (this.priority === null) { this.newExploreCoords(); this.aimAtFocus(); }
      else this.moving = false;
    }
  }

  // LOOTER: true while the player it shot at lies dead (Survivor).
  looting() { return this.lootMark !== null && this.lootMark.corpse; }

  // LOOT: run to the body, then stand over it, facing it, within lootStandM; a body gone (a new run) ends it.
  steerLoot() {
    if (!this.looting()) { this.priority = null; this.sprinting = false; this.actionTimer = 0; return; }
    const b = this.lootMark.position, dx = b.x - this.position.x, dz = b.z - this.position.z, r = RULE_PEOPLE.lootStandM;
    if (dx * dx + dz * dz > r * r) { this.focusX = b.x; this.focusZ = b.z; this.aimAtFocus(); this.moving = true; return; }
    if (this.moving) { this.headToward(b.x, b.z, 1); this.moving = false; this.sprinting = false; }
  }

  // Is `q` still fair game for this night hunter?
  canHunt(q) {
    if (q === null || !q.alive || !ecosystem.night) return false;
    return q === ecosystem.avatar ? q.isPreyFor(this.kindId) : (NIGHT_PREY_MASK[this.kindId] & (1 << q.kindId)) !== 0;
  }

  // PACK STRENGTH: a pack attacks only when its summed mass or height beats q's.
  mayAttack(q) {
    if (this.kindSpec.pack !== true) return true;
    return this.packMassKg >= q.bodyMassKg() || this.packHeightM >= q.bodyHeightM();
  }

  // NIGHT HUNT: run at the quarry, pounce in reach; a lost quarry ends the hunt.
  steerHunt() {
    const q = this.quarry, now = ecosystem.time;
    if (!this.canHunt(q)) {
      this.quarry = null; this.priority = null; this.sprinting = false;
      this.actionTimer = 0;   // decide again next tick
      return;
    }
    if (this.pouncing(now)) return;
    this.focusX = q.position.x; this.focusZ = q.position.z;
    this.aimAtFocus();
    this.moving = true;
    const P = this.pounceSpec;
    if (P === undefined || now < this.nextPounceAt || now < this.heldUntil()) return;
    const dx = this.focusX - this.position.x, dz = this.focusZ - this.position.z, reach = this.leapLength(P);
    if (dx * dx + dz * dz > reach * reach) return;
    this.pounceAt = this.moveAt = now;
    this.playing = P;
    this.nextPounceAt = now + P.moveS + P.cooldownS;
    this.bumpScale = 1;
  }

  pouncing(now) {
    const P = this.pounceSpec;
    return P !== undefined && now - this.pounceAt < P.moveS;
  }

  // a pounce's flight speed and length
  leapSpeed(P) { return P.leapOver * this.sprintSpeed(); }
  leapLength(P) { return this.leapSpeed(P) * P.moveS * (1 - P.leapAt); }

  // A pounce's step: 0 crouched, then flight short of contact; -1 when not pouncing.
  pounceStep() {
    const now = ecosystem.time;
    if (!this.pouncing(now)) return -1;
    const P = this.pounceSpec;
    if ((now - this.pounceAt) / P.moveS < P.leapAt) return 0;
    const q = this.quarry, flight = this.leapSpeed(P) * this.bumpScale * NPC_TICK_S;
    if (q === null) return flight;   // hunt ended mid-air: the leap carries on
    this.headingDir();
    const along = (q.position.x - this.position.x) * this._dirSin + (q.position.z - this.position.z) * this._dirCos;
    return Math.max(0, Math.min(flight, along - Ecosystem.CONTACT_DIST * POUNCE_LAND_SHORT));
  }

  searchDeer(grid) {
    const x = this.position.x, z = this.position.z;
    const vd = this.visionDistSq, r = this.visionDistance;
    this.hasPredator = this.hasFood = this.hasWater = this.hasMate = false;
    this.avoidNeed = 0;
    this.quarry = null;
    this.onSight = null;
    const food = this.food, tid = this.kindId, sex = this.sex;
    // at night, night prey is quarry even if fled by day
    const quarryMask = ecosystem.night ? NIGHT_PREY_MASK[tid] : 0;
    // ARMED: kinds it shoots on sight, and kinds it stands against rather than flees
    const armed = this.gun !== null, sightMask = armed ? SHOOTS_ON_SIGHT_MASK[tid] : 0, standMask = armed ? ARMED_STANDS_MASK[tid] : 0;
    const huntedBy = HUNTED_BY_MASK[tid] & ~quarryMask & ~standMask, foodId = this.foodId;
    const needP = huntedBy !== 0, needQ = quarryMask !== 0, needS = sightMask !== 0;
    // food and night prey in one pick; no early stop, as smaller prey may lie farther
    const needT = (food !== null && food !== 'plant') || needQ;
    const pack = this.kindSpec.pack === true;   // packmates in sight are summed, so no early stop
    const needJ = needQ && pack;   // packmates' hunts to join
    // kinds any branch of the scan below acts on; a neighbour of another kind is skipped before its position is read.
    // Its own kind also counts when it is the other sex (a mate) or this is a pack animal (pack sums, hunts to join).
    const actsOnMask = quarryMask | (foodId >= 0 ? 1 << foodId : 0) | sightMask | huntedBy;
    let bP = Infinity, bM = Infinity, bJ = Infinity, bS = Infinity, kP = -1, kM = -1, kJ = -1, kS = -1;
    let oP = null, oM = null, oJ = null, oS = null;
    // pack sums start with this animal's body
    let packKg = this.bodyMassKg(), packM = this.bodyHeightM();
    _nPrey = 0;   // candidates for the pick (addPrey)

    const cells = grid.cells;
    if (cells !== null) {
      const cols = grid.cols, rows = grid.rows;
      const { cx0, cx1, cy0, cy1, ccx, ccy, K, W } = grid.ringBox(x, z, r);
      const drift = Math.sqrt(ecosystem.drift2);
      const early = W <= cols && cy1 - cy0 < rows;
      for (let k = 0; k <= K; k++) {
        if (k > 0 && early) {
          const L = grid.ringFloor(k) - drift;
          if (L > r) break;
          if (L > 0) {
            const L2 = L * L;
            if ((!needP || bP < L2) && !needT && !pack && (!needJ || bJ < L2) && (!needS || bS < L2) && bM < L2) break;
          }
        }
        const j0 = Math.max(cy0, ccy - k), j1 = Math.min(cy1, ccy + k);
        for (let j = j0; j <= j1; j++) {
          const row = (((j % rows) + rows) % rows) * cols;
          const full = j === ccy - k || j === ccy + k;
          const step = full ? 1 : 2 * k;
          const iEnd = Math.min(cx1, ccx + k);
          for (let i = full ? Math.max(cx0, ccx - k) : ccx - k; i <= iEnd; i += step) {
            if (i < cx0) continue;
            const bucket = cells[row + ((i % cols) + cols) % cols];
            if (bucket === null) continue;
            const base = ((j - cy0) * W + (i - cx0)) * 1048576;
            for (let b = 0; b < bucket.length; b++) {
              const obj = bucket[b];
              if (obj === this || !obj.alive) continue;
              const oid = obj.kindId;
              if ((actsOnMask & (1 << oid)) === 0 && (oid !== tid || (!pack && obj.sex === sex))) continue;
              const ox = obj.position.x, oz = obj.position.z;
              const d2 = (ox - x) * (ox - x) + (oz - z) * (oz - z);
              if (d2 > vd) continue;
              const key = base + b;
              if ((quarryMask & (1 << oid)) !== 0 || oid === foodId) {
                addPrey(obj, d2, key, 1);
              } else if ((sightMask & (1 << oid)) !== 0) {
                if ((d2 < bS || (d2 === bS && key > kS)) && this.inSight(ox, obj.position.y, oz)) { bS = d2; kS = key; oS = obj; }
              } else if ((huntedBy & (1 << oid)) !== 0) {
                if ((d2 < bP || (d2 === bP && key > kP)) && this.inSight(ox, obj.position.y, oz)) { bP = d2; kP = key; oP = obj; }
              } else if (oid === tid) {
                if (pack) { packKg += obj.bodyMassKg(); packM += obj.bodyHeightM(); }
                if (needJ && obj.priority === 'hunt' && (d2 < bJ || (d2 === bJ && key > kJ)) && this.canHunt(obj.quarry) &&
                  this.inSight(ox, obj.position.y, oz)) { bJ = d2; kJ = key; oJ = obj; }
                if (obj.sex !== sex && (d2 < bM || (d2 === bM && key > kM)) && this.inSight(ox, obj.position.y, oz)) { bM = d2; kM = key; oM = obj; }
              }
            }
          }
        }
      }
    }
    if (oP) { this.seen(0, oP.position.x, oP.position.y, oP.position.z); this.avoidNeed = Infinity; }
    if (oM) this.seen(3, oM.position.x, oM.position.y, oM.position.z);
    this.onSight = oS;

    // City: the avatar as predator and night quarry
    const gp = ecosystem.avatar;
    // night quarry (isPreyFor) or food by day and night (isFoodFor: zombies)
    const avatarQuarry = gp.isPreyFor(tid), avatarPrey = avatarQuarry || gp.isFoodFor(foodId);
    // a threat by kind, or a player who aimed at it lately (aimedAtBy)
    const avatarThreat = gp.isThreatTo(tid) || (gp.alive && ecosystem.time < this.avoidPlayerUntil);
    if (avatarThreat || avatarPrey) {
      const ox = gp.position.x, oz = gp.position.z;
      const d2 = (ox - x) * (ox - x) + (oz - z) * (oz - z);
      if (avatarThreat) {
        if (d2 <= vd && d2 <= bP && this.inSight(ox, gp.position.y, oz)) { bP = d2; this.seen(0, ox, gp.position.y, oz); this.avoidNeed = Infinity; }
      } else if (d2 <= vd) addPrey(gp, d2, -1, 1);   // the avatar never wins a tie
    }
    // a pack hunter joins the nearest packmate's attack unless its own pick ranks ahead
    if (oJ) {
      const q = oJ.quarry;
      addPrey(q, (q.position.x - x) * (q.position.x - x) + (q.position.z - z) * (q.position.z - z), -1, 0);
    }

    // of the candidates this pack can take, the smallest, then nearest
    this.packMassKg = packKg; this.packHeightM = packM;
    // the pick: size step, squared distance, tie key, target
    let sT = Infinity, bT = Infinity, kT = -1, oT = null;
    const bySize = this.kindSpec.nearestPrey !== true;   // true: smallest then nearest (coyotes); false: nearest only (zombies)
    for (let i = 0; i < _nPrey; i++) {
      const obj = _preyObj[i], d2 = _preyD2[i], key = _preyKey[i];
      _preyObj[i] = null;   // let go of the reference
      if (!this.mayAttack(obj)) continue;
      const s = bySize ? Animal.preySize(obj) : 0;
      if (!(Animal.preyAhead(s, d2, sT, bT) || (s === sT && d2 === bT && key > kT))) continue;
      if (_preySight[i] === 1 && !this.inSight(obj.position.x, obj.position.y, obj.position.z)) continue;
      sT = s; bT = d2; kT = key; oT = obj;
    }
    // the pick shows as the food ray; night prey is hunted, food chased when hunger leads
    this.prey = oT;
    if (oT) {
      if (oT === gp ? avatarQuarry : (quarryMask & (1 << oT.kindId)) !== 0) this.quarry = oT;
      this.seen(1, oT.position.x, oT.position.y, oT.position.z);
    }

    if (food === 'plant') {
      const plant = ecosystem.plantSight.nearest(x, z, r, vd, true);
      if (plant) this.seen(1, plant.position.x, plant.position.y, plant.position.z);
    }

    const w = ecosystem.waterSight.nearest(x, z, r, vd, false);
    if (w) this.seen(2, w.position.x, w.position.y, w.position.z);
  }

  // Is the eye's line to (tx, ty, tz) clear of cover?
  inSight(tx, ty, tz) {
    return !cover.blocks(this.position.x, this.eyeY(), this.position.z, tx, ty, tz);
  }

  // Metres moved this tick: pounce, sprint or walk.
  stepLength() {
    const leap = this.pounceStep();
    if (leap >= 0) return leap;
    const ms = this.runs() ? this.sprintSpeed() : this.moveSpeed() * this.speedScale * NPC_UNIT;
    return (this.submerged ? ms * this.WATER_SPEED_FACTOR : ms) * this.bumpScale * NPC_TICK_S;
  }

  // sprint m/s
  sprintSpeed() { return DEER_SPRINT_OVER * Math.max(RUN_SPEED, ecosystem.fastestHunterMSById[this.kindId]); }

  // City: deer slide along walls like the car.
  moveDeer(step) {
    const p = this.position, w = Animal._wallPos;
    const feet = this._b ?? baseAt(p.x, p.z);
    const n = Math.max(1, Math.ceil(step / NPC_SUBSTEP));
    const b0 = this.bumpScale || 1;
    const d0 = step / n;
    for (let k = 0; k < n; k++) {
      const d = d0 * (this.bumpScale / b0);
      this.headingDir();
      const fx = this._dirSin, fz = this._dirCos;
      p.x = ecosystem.fitX(p.x + fx * d);
      p.z = ecosystem.fitZ(p.z + fz * d);
      w.set(p.x, 0, p.z);
      if (!resolveCollisions(w, NPC_RADIUS, feet, feet + NPC_COLLIDE_H, STEP_UP)) continue;
      const px = w.x - p.x, pz = w.z - p.z;
      p.x = w.x; p.z = w.z;
      const len = Math.hypot(px, pz);
      if (len < 1e-6) continue;
      const nx = px / len, nz = pz / len;
      const dot = fx * nx + fz * nz;
      if (dot < 0) this.bumpScale *= 1 - dot * dot;
      if (Math.abs(dot) < CAR_GLANCE) {
        let tx = -nz, tz = nx;
        if (tx * fx + tz * fz < 0) { tx = -tx; tz = -tz; }
        let dy = Math.atan2(tx, tz) - this.heading;
        dy = Math.atan2(Math.sin(dy), Math.cos(dy));
        this.heading = this.targetHeading = wrapAngle(this.heading + dy * CAR_ALIGN);
      }
    }
  }

  // Record a sighting (0 predator, 1 food, 2 water, 3 mate) for the arrows.
  seen(kind, ox, oy, oz) {
    const dx = ox - this.position.x, dz = oz - this.position.z;
    const h = Math.hypot(dx, dz) || 1;
    const s = dx / h, c = dz / h, dist = Math.min(1, h / this.visionDistance);
    if (kind === 0) {
      this.memPredatorX = ox; this.memPredatorY = oy; this.memPredatorZ = oz; this.hasPredator = true;
      this.rayPredatorSin = s; this.rayPredatorCos = c; this.rayPredatorDist = dist;
    } else if (kind === 1) {
      this.memFoodX = ox; this.memFoodY = oy; this.memFoodZ = oz; this.hasFood = true;
      this.rayFoodSin = s; this.rayFoodCos = c; this.rayFoodDist = dist;
    } else if (kind === 2) {
      this.memWaterX = ox; this.memWaterY = oy; this.memWaterZ = oz; this.hasWater = true;
      this.rayWaterSin = s; this.rayWaterCos = c; this.rayWaterDist = dist;
    } else {
      this.memMateX = ox; this.memMateY = oy; this.memMateZ = oz; this.hasMate = true;
      this.rayMateSin = s; this.rayMateCos = c; this.rayMateDist = dist;
    }
  }

  // species.py new_explore_coords; City: up to 10 draws for an open outdoor spot.
  newExploreCoords() {
    for (let k = 0; k < 10; k++) {
      this.focusX = ecosystem.minX + Math.random() * (ecosystem.maxX - ecosystem.minX);
      this.focusZ = ecosystem.minZ + Math.random() * (ecosystem.maxZ - ecosystem.minZ);
      if (isOpen(this.focusX, this.focusZ)) return;
    }
  }

  static _wallPos = new THREE.Vector3();

  // PREY CHOICE: `q`'s size in PREY_SIZE_STEP_KG steps
  static preySize(q) { return Math.round(q.bodyMassKg() / PREY_SIZE_STEP_KG); }
  // PREY CHOICE: does size s at d2 rank ahead of (sB, dB)? smaller, then nearer
  static preyAhead(s, d2, sB, dB) { return s < sB || (s === sB && d2 < dB); }

  move() {
    const lift = this.footLift() * NPC_UNIT;
    const free = ecosystem.time >= this.heldUntil();   // true: not held by a fight move or a knockdown
    // TURNING, walking or standing (a fighter turns in place): toward targetHeading at turnRate
    if (free && this.heading !== this.targetHeading) {
      this.heading = turnToward(this.heading, this.targetHeading, this.turnRate * NPC_TICK_S);
    }
    if (free) this.facingAngle = this.heading;
    if (this.moving && free) {
      const step = this.stepLength();
      this.headingDir();
      const sx = this._dirSin * step, sz = this._dirCos * step;
      const n = Math.ceil(step / NPC_SUBSTEP);
      if (!this.brain) {
        this.moveDeer(step);
      } else if (n <= 1) {
        // walking step: Ecosystem.collide settles walls
        this.position.x = ecosystem.fitX(this.position.x + sx);
        this.position.z = ecosystem.fitZ(this.position.z + sz);
      } else {
        // sprinting step: sub-steps refused or slid at blocked cells
        let x = this.position.x, z = this.position.z;
        for (let k = 0; k < n; k++) {
          const nx = ecosystem.fitX(x + sx / n);
          const nz = ecosystem.fitZ(z + sz / n);
          if (!occ.blockedAt(nx, nz)) { x = nx; z = nz; }
          else if (!occ.blockedAt(nx, z)) x = nx;
          else if (!occ.blockedAt(x, nz)) z = nz;
          else break;
        }
        this.position.x = x; this.position.z = z;
      }
    }
    // footing: base (floor, ground or water) + dip, floating past the float depth
    const g = surfaceFor(this, this.position.x, this.position.z);
    const floatY = -this._fd;
    this.floating = g < floatY;
    this.submerged = g < 0;
    this.position.y = this._b + (this.floating ? floatY : g) + lift;
  }

  update(now, grid) {
    this.waterNeed += this.waterIncrement;
    this.foodNeed += this.foodIncrement;
    if (!this.isAdult && ecosystem.ticks - this.birthTick >= NPC_MATURITY_TICKS) {
      this.isAdult = true;
      this.ageBase = NPC_ADULT_AGE;
      this.ageBaseTick = ecosystem.ticks;
    }
    this.lookForMate = this.mateReady(now);
    // people: the Arena's rule; deer: species.py's
    const rn = this.reproductionNeed;
    this.reproductionNeed = !this.lookForMate ? 0
      : this.brain ? Math.min(rn + rn, REPRO_NEED_MAX) : rn + this.reproductionIncrement;
    this.health -= (now - this.tob) * this.ageDepl
      + this.waterNeed * 0.0001
      + this.foodNeed * 0.0001;
    this.avoidNeed = 0;
    if (this.health <= Animal.DEATH_HEALTH) { this.alive = false; return; }
    if (now >= this.turnAt) this.turn();
    regenStep(this, this.maxHealth, NPC_NEED_FULL, Animal.DRINK_SHARE_PER_S, NPC_TICK_S);
    if (this.fleeFrom !== null && now >= this.heldUntil()) this.fleeAttacker();

    if (!this.brain) {
      // City: deer decide every DEER_THINK_TICKS (staggered) and steer every tick
      if (--this.actionTimer <= 0 && !this.pouncing(now)) {
        this.thinkDeer(grid);
        this.actionTimer = this.ACTION_HOLD;
      }
      this.steerDeer();
    } else if (--this.actionTimer <= 0) {
      // credit the held decision, then make the next
      this.learnFromLastDecision();
      this.think(grid);
      this.actionTimer = this.ACTION_HOLD;
    }
    this.move();
    if (this.gun !== null) this.shootStep(now);
  }

  // ARMED PEOPLE (RULE_PEOPLE): what to shoot, or null: its fight target, else the prey being chased once hunger
  // reaches huntHungerShare (a kill feeds it, so it stops until hungry again); each only when alive, within rangeM and
  // in sight.
  shootTarget(now) {
    const fight = this.fightTarget(now);
    if (fight !== null) return fight;
    const hungry = this.foodNeed >= RULE_PEOPLE.huntHungerShare * NPC_NEED_FULL;   // true: hungry enough to hunt
    if (hungry && this.priority === 'food' && this.canShoot(this.prey)) return this.prey;
    return null;
  }
  // FIGHT: the last attacker while it is a foe, else (a looter) a Survivor player, else what it shoots on sight; or null.
  fightTarget(now) {
    if (now < this.foeUntil && this.canShoot(this.foe)) return this.foe;
    if (this.looter && this.canShoot(ecosystem.avatar)) return ecosystem.avatar;   // alive only in Survivor play
    if (this.canShoot(this.onSight)) return this.onSight;
    return null;
  }
  canShoot(t) {
    if (t === null || !t.alive) return false;
    const dx = t.position.x - this.position.x, dz = t.position.z - this.position.z, r = RULE_PEOPLE.rangeM;
    return dx * dx + dz * dz <= r * r && this.inSight(t.position.x, t.position.y, t.position.z);
  }

  // ARMED PEOPLE: volleys of one or two shots (RULE_PEOPLE fire cadence), each from the eye at the target's body centre,
  // off by up to its aimErrorRad each way, with the gun's sound. A kill feeds the shooter, as a coyote's bite does.
  shootStep(now) {
    if (now < this.nextShotAt || this.isDown(now)) return;
    const t = this.shootTarget(now);
    if (t === null) { this.pairShotDue = false; return; }   // a lost target drops a pending second shot
    const ex = this.position.x, ey = this.eyeY(), ez = this.position.z;
    const dx = t.position.x - ex, dy = Projectiles.centreY(t) - ey, dz = t.position.z - ez, len = Math.hypot(dx, dy, dz);
    if (len < 1e-6) return;
    const S = this.aimErrorRad;
    // it turns to the target (TURN_RATES) and fires only once facing it within fireConeRad
    const bearing = Math.atan2(dx, dz), off = bearing - this.facingAngle;
    this.headToward(t.position.x, t.position.z, 1);
    if (Math.abs(Math.atan2(Math.sin(off), Math.cos(off))) > RULE_PEOPLE.fireConeRad) return;
    const yaw = bearing + (Math.random() * 2 - 1) * S, pitch = Math.asin(dy / len) + (Math.random() * 2 - 1) * S;
    if (this.looter && t === ecosystem.avatar) this.lootMark = t;   // its body is this looter's once dead
    ecosystem.projectiles.fire(this, ex, ey, ez, Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch),
      this.gun, true, true);
    sound.emit('gunshot', ex, ey, ez, this);
    this.lastShotAt = now;
    this.scheduleNextShot(now);
  }
  // FIRE CADENCE: a shot that opens a volley makes it a pair with pairShare (next shot after pairGapS); the volley's
  // last shot waits restS. Both gaps are drawn evenly in their [min, max].
  scheduleNextShot(now) {
    const startsPair = !this.pairShotDue && Math.random() < RULE_PEOPLE.pairShare;   // true: this shot opens a pair
    const [lo, hi] = startsPair ? RULE_PEOPLE.pairGapS : RULE_PEOPLE.restS;
    this.pairShotDue = startsPair;
    this.nextShotAt = now + lo + Math.random() * (hi - lo);
  }

  // Reward: mean health, food and water gained, clipped to [-1, 1].
  learnFromLastDecision() {
    const gained = (this.health - this.prevHealth)
      + (this.prevFoodNeed - this.foodNeed)
      + (this.prevWaterNeed - this.waterNeed);
    const reward = gained / (3 * this.startHealth * 0.05);
    this.brain.adjustWeights(Math.max(-1, Math.min(1, reward)));
    this.prevHealth = this.health;
    this.prevWaterNeed = this.waterNeed;
    this.prevFoodNeed = this.foodNeed;
  }

  // A hit's damage: no eating for NPC_HIT_NO_EAT_S; a kill feeds the attacker when `feeds` (false for bump impacts).
  takeHit(attacker, damage, feeds = true) {
    this.health -= damage;
    this.noEatUntil = ecosystem.time + NPC_HIT_NO_EAT_S;
    if (this.health <= Animal.DEATH_HEALTH) {
      this.alive = false;
      if (feeds) attacker.feedOn(this);
    } else { this.rollBone(damage); this.answerHit(attacker); }
  }

  // A striker landing a hit: its move, facing the target, holding ground.
  strike(target) {
    this.headToward(target.position.x, target.position.z, 1);
    startFightMove(this, NPC_FIGHT_MOVES[this.type], ecosystem.time);
  }

  // A fleeing species answers a hit with its move, then runs; once per fleeS.
  answerHit(attacker) {
    const move = NPC_FIGHT_MOVES[this.type], now = ecosystem.time;
    if (this.gun !== null && attacker !== this) {   // shot back; a car hit came from its driver, the player
      this.foe = attacker.type === 'car' ? ecosystem.avatar : attacker;
      this.foeUntil = now + RULE_PEOPLE.foeS;
    }
    if (!move.flees || now < this.fleeUntil) return;
    this.headToward(attacker.position.x, attacker.position.z, -1);
    startFightMove(this, move, now);
    this.fleeFrom = attacker;
    this.fleeUntil = now + move.moveS + move.fleeS;
  }

  // Move over: sprint away; it keeps fleeing while the attacker is in sight.
  fleeAttacker() {
    const f = this.fleeFrom;
    this.fleeFrom = null;
    this.seen(0, f.position.x, f.position.y, f.position.z);
    this.priority = 'predator';
    this.headToward(f.position.x, f.position.z, -1);
    this.sprinting = true;
    this.speedScale = this.bumpScale = 1;
    this.moving = true;
    this.actionTimer = this.ACTION_HOLD;
  }

  // AIMED AT (Survivor): the player's aim line on a rule person; armed, the player is its foe, else a threat it flees.
  aimedAtBy(player, now) {
    if (this.brain !== null || this.zombie) return;
    if (this.gun !== null) { this.foe = player; this.foeUntil = now + RULE_PEOPLE.foeS; }
    else this.avoidPlayerUntil = now + RULE_PEOPLE.foeS;
  }

  // Head toward (1) or away from (-1) (x, z): people turn there at turnRate (move), a kind with no TURN_RATES entry
  // faces it at once.
  headToward(x, z, sign) {
    const dx = (x - this.position.x) * sign, dz = (z - this.position.z) * sign;
    if (dx === 0 && dz === 0) return;
    const a = wrapAngle(Math.atan2(dx, dz));
    this.targetHeading = a;
    if (this.turnRate === Infinity) this.heading = this.facingAngle = a;
  }

  // A kill's meal: the victim's starting health as food and water (health comes back by REGEN only).
  feedOn(victim) {
    this.foodNeed = Math.max(0, this.foodNeed - victim.startHealth);
    this.dietWater(victim.startHealth);
  }

  // City: water eaten with `food` units of food.
  dietWater(food) {
    const perFood = DIET_WATER_SHARE * this.waterIncrement / this.foodIncrement;
    this.waterNeed = Math.max(0, this.waterNeed - food * perFood);
  }

  ageYears() {
    return this.ageBase + (ecosystem.ticks - this.ageBaseTick) / NPC_TICKS_PER_YEAR;
  }

  // GROWTH: drawn size share, GROWTH_MIN_SCALE at birth to 1 at maturity.
  growthScale() {
    const growth = this.isAdult ? 1 : Math.min(1, (ecosystem.ticks - this.birthTick) / NPC_MATURITY_TICKS);
    return GROWTH_MIN_SCALE + (1 - GROWTH_MIN_SCALE) * growth;
  }
  // Metres per rig unit as drawn.
  rigScale() { return this.growthScale() * NPC_UNIT * this.heightScale; }
  // The drawn rig's origin height: a young body's centre sits lower by the lift it has not grown into.
  originY() { return this.position.y - (1 - this.growthScale()) * this.footLift() * NPC_UNIT; }

  // Drawn height in metres.
  bodyHeightM() {
    return this.adultHeightM() * this.growthScale();
  }

  // BODY RATES: pace (the look's, 1 for animals) and the Arena move speed per second (speed gene x pace) depend only
  // on the speed gene and the look, both fixed for life once an animal is made. The constructor and mate (after the
  // child's genes) are the only writers of either, and both call this; pace() and moveSpeed() read the stored values.
  setBodyRates() {
    this.paceShare = this.look ? this.look.pace : 1;
    this.moveSpeedPerS = this.speed * this.paceShare;
    // ENERGY: hunger scales with the speed gene, strength, toughness and adult mass, each over its species reference
    this.foodIncrement = this.startHealth * NPC_FOOD_PER_HEALTH_TICK * (this.speed / this.spec.speed) * this.strength *
      this.toughness * (this.massAtHeightKg(this.adultHeightM()) / REF_ADULT_KG[this.type]);
    this.reproductionIncrement = this.foodIncrement * DEER_REPRO_SHARE;
  }
  // HERITABLE GENES: toughness and the max health it sets; a new body starts full
  setToughness(t) {
    this.toughness = t;
    this.maxHealth = this.health = this.startHealth * t;
  }
  // The rule AI's food: a kind, 'plant' or null, and its kind id (-1 for plants or nothing).
  setFood(food) {
    this.food = food;
    this.foodId = NPC_KIND_IDS[food] ?? -1;
  }
  // ZOMBIES: an infecting hit; it turns ZOMBIES.turnS later, unless it is already infected or a zombie
  infect(now) {
    if (!this.zombie && this.turnAt === Infinity) this.turnAt = now + ZOMBIES.turnS;
  }
  // ZOMBIES: the virus takes hold; the rule AI from now on, hunting ZOMBIES.food, with no brain or gun
  turn() {
    this.zombie = true;
    this.turnAt = Infinity;
    this.kindId = ZOMBIE_KIND_ID;
    this.kindSpec = ZOMBIES;
    this.brain = null;
    this.ACTION_HOLD = DEER_THINK_TICKS;
    this.actionTimer = 0;   // decide as a zombie next tick
    this.gun = null; this.foe = null; this.foeUntil = 0; this.onSight = null;
    this.setFood(ZOMBIES.food);
    this.prey = null; this.quarry = null; this.priority = null;
  }
  // Kind name, as SURVIVOR_CONFIG.causes keys it.
  get kind() { return NPC_KINDS[this.kindId]; }
  // BROKEN BONES: one roll per hit it lives through; toughness divides the chance below the sure share
  rollBone(damage) {
    if (this.brokenBone) return;
    const sure = damage >= BROKEN_BONE.sureDamageShare * this.maxHealth;   // true: always breaks; false: the chance
    if (sure || Math.random() < BROKEN_BONE.chanceBelowSure / this.toughness) this.brokenBone = true;
  }
  // Sprinting this tick: wanted and not stopped by a broken bone.
  runs() { return this.sprinting && !this.brokenBone; }
  // Body pace: the look's, 1 for animals.
  pace() { return this.paceShare; }
  // Arena speed per second: speed gene x pace.
  moveSpeed() { return this.moveSpeedPerS; }
  // Jump takeoff speed (bodyJumpSpeed). Not called yet.
  jumpSpeed(baseSpeed) { return bodyJumpSpeed(baseSpeed, this.pace()); }

  // Fighting mass in kg: people by humanFightMassKg, animals at the reference man's share.
  fightMassKg() {
    return this.type === 'human' ? humanFightMassKg(this.sex, this.look, this.bodyHeightM())
      : this.bodyMassKg() * NPC_ANIMAL_FIGHT_SHARE;
  }

  // KNOCKDOWNS: health share x energy share
  condition() { return conditionShare(this.health, this.maxHealth, this.foodNeed, this.waterNeed); }
  // no steps until the later of the fight hold and a knockdown
  heldUntil() { return Math.max(this.fightUntil, this.downUntil); }
  // knocked down: neither attacks nor mates (the brain still thinks)
  isDown(now) { return now < this.downUntil; }
  // BUMPING: m/s along its heading this tick, 0 while held
  groundSpeed(now) { return this.moving && now >= this.heldUntil() ? this.stepLength() / NPC_TICK_S : 0; }
  // BUMP IMPACTS: m/s of this tick's velocity along the unit direction (nx, nz)
  speedAlong(nx, nz, now) { return (Math.sin(this.heading) * nx + Math.cos(this.heading) * nz) * this.groundSpeed(now); }
  // KNOCKDOWNS: can a push knock it down (applyHit)? Every living animal; the avatar has its own rule
  knockable() { return this.alive; }
  // KNOCKDOWNS: braced on its feet (applyHit)? Every animal; the avatar has its own rule
  braced() { return true; }

  // Mass in kg: people by humanMassKg, animals by reference mass x height ratio^3.
  bodyMassKg() { return this.massAtHeightKg(this.bodyHeightM()); }
  // Mass in kg at height h: people by humanMassKg, animals by reference mass x height ratio^3.
  massAtHeightKg(h) {
    if (this.type === 'human') return humanMassKg(this.sex, this.look, h);
    const k = h / NPC_SIZE[this.type][this.sex][0];
    return NPC_REF_MASS_KG[this.type][this.sex] * k * k * k;
  }
  // Height in metres once grown.
  adultHeightM() { return this.heightScale * NPC_SIZE[this.type].rig * NPC_UNIT; }

  // Adult size from a z-score, cut at NPC_SIZE_Z_MAX.
  setSizeZ(z) {
    this.sizeZ = Math.max(-NPC_SIZE_Z_MAX, Math.min(NPC_SIZE_Z_MAX, z));
    const sz = NPC_SIZE[this.type], [mean, std] = sz[this.sex];
    this.heightScale = (mean + std * this.sizeZ) / (sz.rig * NPC_UNIT);
  }

  // Mate bar fill; only an adult with a full bar mates.
  mateFill(now) {
    return this.isAdult ? (now - this.lastChildTime) / this.childGracePeriod : 0;
  }
  mateReady(now) {
    return this.isAdult && this.mateFill(now) >= 1;
  }

  mate(partner) {
    const mm = this.mutationMulti;
    const lo = Math.max(0.1, 1 - mm);
    const hi = Math.min(1.1, 1 + mm);
    const rand = () => lo + Math.random() * (hi - lo);

    const mother = this.sex === 'female' ? this : partner;
    const child = new Animal(
      [mother.position.x, mother.position.y,
      mother.position.z + this.spec.childDrop * NPC_UNIT],
      this.type
    );
    child.isAdult = false;
    child.birthTick = ecosystem.ticks;
    child.home = mother.home;

    child.speed = ((this.speed + partner.speed) / 2) * rand();   // setBodyRates below
    child.strength = ((this.strength + partner.strength) / 2) * rand();   // setBodyRates below
    child.setToughness(((this.toughness + partner.toughness) / 2) * rand());
    child.visionDistance = ((this.visionDistance + partner.visionDistance) / 2) * rand();
    child.visionDistSq = child.visionDistance * child.visionDistance;
    child.setFov(
      ((this.fovH + partner.fovH) / 2) * rand(),
      ((this.fovV + partner.fovV) / 2) * rand()
    );
    child.eyeOffset = (this.eyeOffset + partner.eyeOffset) / 2;
    child.mutationMulti = ((this.mutationMulti + partner.mutationMulti) / 2)
      * (0.9 + Math.random() * 0.2);

    // mid-parent z x heritability plus noise; variance stays 1
    const midZ = (this.sizeZ + partner.sizeZ) / 2, h = NPC_SIZE_HERITABILITY;
    child.setSizeZ(h * midZ + Math.sqrt(1 - h * h / 2) * tools.gauss());
    if (child.look) inheritHumanLook(child.look, this.look, partner.look);
    child.setBodyRates();   // speed, strength, toughness and look are final from here
    if (this.zombie) child.turn();   // ZOMBIES: zombies mate only zombies (tryMate), and their young are born turned

    if (child.brain && this.brain && partner.brain) {   // a child rolled brainless (RULE_PEOPLE) stays so
      const ParentBrain = Math.random() < 0.5 ? this.brain : partner.brain;
      // the parent's wiring, mutated; weights fresh
      const childMasks = brains.mutateMasks(ParentBrain.getMasks(), ParentBrain.inputDims,
        ParentBrain.outputDims, child.mutationMulti / 0.5);
      child.brain = new SpikingNetwork(
        ParentBrain.inputDims,
        ((this.brain.learningRate + partner.brain.learningRate) / 2)
        * (0.5 + Math.random()),
        ParentBrain.weightDecay,
        childMasks
      );
    }

    child.generation = Math.max(this.generation, partner.generation) + 1;

    const now = ecosystem.time;
    this.lastChildTime = now;
    this.lookForMate = false;
    this.reproductionNeed = 0;
    partner.lastChildTime = now;
    partner.lookForMate = false;
    partner.reproductionNeed = 0;

    return child;
  }

  eatPlant(plant) {
    const nutrition = plant.maxHealth * PLANT_BITE_NUTRITION;
    this.foodNeed = Math.max(0, this.foodNeed - nutrition * 0.01);
    this.dietWater(nutrition * 0.01);
    plant.health -= 1;
    plantView.touch(plant);
    if (plant.health <= 0) { plant.alive = false; ecosystem.plantsDied = true; }
  }

  // A food box: hunger cleared; the crate moves.
  eatBox() {
    this.dietWater(this.foodNeed);
    this.foodNeed = 0;
  }

  // Every species drinks alike: an empty bar refills in NPC_DRINK_SECONDS.
  static DRINK_SHARE_PER_S = 1 / NPC_DRINK_SECONDS;   // water bar share drinking fills per second (also REGEN's rate)
  drinkWater() {
    this.waterNeed = Math.max(0, Math.min(this.waterNeed, 100) - 100 * Animal.DRINK_SHARE_PER_S * NPC_TICK_S);
  }
}

export function humanLook(sex) {
  const pick = list => list[Math.floor(Math.random() * list.length)];
  const outfit = Math.floor(Math.random() * HUMAN_OUTFITS), shirt = outfit === 5 ? pick(HUMAN_SUITS) : pick(HUMAN_SHIRTS);
  const look = {
    tone: Math.random(), variant: Math.floor(Math.random() * HUMAN_FACE_VARIANTS), female: sex === 'female',
    bodyType: 0, endo: 0, meso: 0, ecto: 0, bodyFat: 0, bmi: 0, pace: 1, build: 0, shape: newShape(), outfit, shirt,
    pants: outfit === 5 ? shirt : pick(HUMAN_PANTS), skinRGB: 0, code: 0
  };
  drawFounderBody(look);
  setHumanBody(look);
  packHumanLook(look);
  return look;
}

const clampTo = (v, [lo, hi]) => Math.max(lo, Math.min(hi, v));
// pure type per readout body type
const PURE_TYPE = { ecto: 'ectomorph', meso: 'mesomorph', endo: 'endomorph' };

// The player's Custom body: bodyType, bodyFat and bmi set; pace and shape follow.
export function customizeHumanLook(L, { bodyType, bodyFat, bmi }) {
  L.bodyType = NPC_SOMATOTYPES.findIndex(t => t.name === PURE_TYPE[bodyType]);
  for (const k in BODY_TYPE_NAMES) setBodyTrait(L, k, 0);
  L.bodyFat = clampTo(bodyFat, NPC_BODY_FAT_LIMITS);
  setHumanBody(L);
  L.bmi = bmi;
  setHumanShape(L);
  packHumanLook(L);
}
// a trait's population curve; fat differs by sex
const bodyPop = (trait, female) => trait === 'bodyFat' ? NPC_BODY_POP.bodyFat[female ? 'female' : 'male'] : NPC_BODY_POP[trait];
// a look's drawn widths
const newShape = () => Object.fromEntries([...NPC_TORSO_REGIONS, 'limb'].map(k => [k, 1]));

// a somatotype by weight
function pickBodyType() {
  let roll = Math.random() * NPC_SOMATOTYPES.reduce((s, t) => s + t.weight, 0);
  const i = NPC_SOMATOTYPES.findIndex(t => (roll -= t.weight) < 0);
  return i < 0 ? NPC_SOMATOTYPES.length - 1 : i;
}
// A trait's [mean, sd] within a somatotype.
const typeCurve = (typeIndex, trait, female) => {
  const t = NPC_SOMATOTYPES[typeIndex];
  return trait === 'bodyFat' ? t.bodyFat[female ? 'female' : 'male'] : [t.ratings[trait], NPC_RATING_SPREAD];
};
// Sets a trait from its z-score on the look's type curve, within limits.
function setBodyTrait(L, trait, z) {
  const [mean, sd] = typeCurve(L.bodyType, trait, L.female);
  L[trait] = clampTo(mean + sd * z, trait === 'bodyFat' ? NPC_BODY_FAT_LIMITS : NPC_RATING_LIMITS);
}

// A founder's ratings and fat: a type by weight, varied within it.
function drawFounderBody(L) {
  L.bodyType = pickBodyType();
  for (const k of NPC_BODY_TRAITS) setBodyTrait(L, k, tools.gauss());
}

// Derives bmi from ratings and fat, then the drawn widths.
function setHumanBody(L) {
  const sex = L.female ? 'female' : 'male';
  const leanIndex = NPC_LEAN_INDEX_BASE[sex] + NPC_LEAN_PER_MESO * (L.meso - NPC_LEAN_REF_RATING) + NPC_LEAN_PER_ECTO * (L.ecto - NPC_LEAN_REF_RATING);
  L.bmi = leanIndex / (1 - L.bodyFat);                   // lean mass / (1 - fat), per m^2
  // pace: lean share over the reference's, to NPC_PACE_LEAN_EXP
  L.pace = clampTo(((1 - L.bodyFat) / (1 - NPC_REF_BODY_FAT[sex])) ** NPC_PACE_LEAN_EXP, NPC_PACE_LIMITS);
  setHumanShape(L);
}

// DRAWN BODY SHAPE: build from bmi, split among regions by NPC_BUILD_BASE.
function setHumanShape(L) {
  const sex = L.female ? 'female' : 'male', base = NPC_BUILD_BASE[sex], baseMean = NPC_BUILD_BASE_MEAN[sex];
  L.build = clampTo(baseMean + Math.sqrt(L.bmi / NPC_REF_BMI[sex]) - 1, NPC_WIDTH_LIMITS);
  // a region's width per unit of build
  const share = k => base[k] / baseMean;
  // a region's relative width from each trait's z-score
  const rel = {};
  for (const k in NPC_BODY_SHAPE) {
    rel[k] = 1;
    for (const t in NPC_BODY_SHAPE[k]) {
      const p = bodyPop(t, L.female);
      rel[k] += NPC_BODY_SHAPE[k][t] * (L[t] - p.mean) / p.sd;
    }
  }
  // torso mean over build, so composition moves width between regions only
  let torsoMean = 0;
  for (const k of NPC_TORSO_REGIONS) torsoMean += share(k) * rel[k] / NPC_TORSO_REGIONS.length;
  for (const k of NPC_TORSO_REGIONS) L.shape[k] = clampTo(L.build * share(k) * rel[k] / torsoMean, NPC_WIDTH_LIMITS);
  L.shape.limb = clampTo(L.build * share('limb') * rel.limb, NPC_WIDTH_LIMITS);
}

// A person at the population's mean body: the billboard bake's bodies.
export function averageHumanLook(female, outfit, variant) {
  const sex = female ? 'female' : 'male';
  const L = {
    tone: 0, variant, female, endo: NPC_BODY_POP.endo.mean, meso: NPC_BODY_POP.meso.mean, ecto: NPC_BODY_POP.ecto.mean,
    bodyFat: NPC_BODY_POP.bodyFat[sex].mean, bmi: NPC_REF_BMI[sex], build: 0, shape: newShape(), outfit, shirt: 0,
    pants: 0, skinRGB: 0, code: 0
  };
  setHumanShape(L);
  packHumanLook(L);
  return L;
}

// skinRGB as one integer; code: face + outfit * 8 + girth * 64.
function packHumanLook(L) {
  const t = L.tone * (HUMAN_SKIN.length - 1), i = Math.min(HUMAN_SKIN.length - 2, Math.floor(t)), f = t - i;
  const mix = sh => Math.round(((HUMAN_SKIN[i] >> sh) & 255) * (1 - f) + ((HUMAN_SKIN[i + 1] >> sh) & 255) * f);
  L.skinRGB = mix(16) * 65536 + mix(8) * 256 + mix(0);
  L.code = (L.female ? HUMAN_FACE_VARIANTS : 0) + L.variant + L.outfit * 8 +
    Math.round((L.shape.limb - NPC_WIDTH_LIMITS[0]) * NPC_GIRTH_STEPS) * 64;
}

function inheritHumanLook(L, a, b) {
  L.tone = Math.max(0, Math.min(1, (a.tone + b.tone) / 2 + (Math.random() - 0.5) * 0.12));
  L.variant = (Math.random() < 0.5 ? a : b).variant;
  // somatotype: a parent's by heritability, else fresh by weight
  L.bodyType = Math.random() < NPC_BODY_TYPE_HERITABILITY ? (Math.random() < 0.5 ? a : b).bodyType : pickBodyType();
  // each trait's z: mid-parent x heritability plus noise
  const zOf = (P, k) => { const [mean, sd] = typeCurve(P.bodyType, k, P.female); return (P[k] - mean) / sd; };
  for (const k of NPC_BODY_TRAITS) {
    const h = NPC_BODY_HERITABILITY[k], midZ = (zOf(a, k) + zOf(b, k)) / 2;
    setBodyTrait(L, k, h * midZ + Math.sqrt(1 - h * h / 2) * tools.gauss());
  }
  setHumanBody(L);
  packHumanLook(L);
}

// PLANTS: the Arena's Plant; stem and four leaves that shrink with health.

// PLANT VIEW: the plant renderer's add, remove and touch hooks.
export const plantView = { add: null, remove: null, touch: null, pending: false };

class Plant extends Entity {
  constructor(position) {
    super(position, 'plant');
    this.health = PLANT_MAX_HEALTH;
    this.maxHealth = PLANT_MAX_HEALTH;
    // On the provider's footing, sunk 3 Arena units.
    const x = this.position.x, z = this.position.z;
    this.position.y = surfaceY(x, z) - 3 * NPC_UNIT;
    this._slot = -1;
    this._cell = null;
    this._sightKey = -1;
    this._gridKey = -1;
    plantView.add(this);
  }

  remove() { plantView.remove(this); }

  update() {
    // past MAX_INSTANCES: retry each tick for a freed slot
    if (this._slot < 0) plantView.add(this);
  }
}

// Entry t in [0, 1] of segment a + d t into a vertical cylinder (centre cx, cz, radius r, height lo..hi), or Infinity.
function cylinderHit(ax, ay, az, dx, dy, dz, cx, cz, r, lo, hi) {
  const fx = ax - cx, fz = az - cz, a2 = dx * dx + dz * dz, c = fx * fx + fz * fz - r * r;
  let t0 = 0, t1 = 1;
  if (a2 < 1e-12) { if (c > 0) return Infinity; }   // straight up or down: inside the circle or not
  else {
    const b = fx * dx + fz * dz, disc = b * b - a2 * c;
    if (disc < 0) return Infinity;
    const s = Math.sqrt(disc);
    t0 = Math.max(0, (-b - s) / a2); t1 = Math.min(1, (-b + s) / a2);
  }
  return clipSpanY(t0, t1, ay, dy, lo, hi);
}

// Entry t in [0, 1] of segment a + d t into the car's box (Ecosystem.fallBox's shape), or Infinity.
function boxHit(ax, ay, az, dx, dy, dz, b) {
  const rx = ax - b.cx, rz = az - b.cz;
  const slabs = [   // [start, change per t, half size] along the box's front and right axes
    [rx * b.fx + rz * b.fz, dx * b.fx + dz * b.fz, b.halfLen],
    [rx * b.sx + rz * b.sz, dx * b.sx + dz * b.sz, b.halfWid]
  ];
  let t0 = 0, t1 = 1;
  for (const [p, d, h] of slabs) {
    if (d === 0) { if (p < -h || p > h) return Infinity; continue; }
    const u = (-h - p) / d, v = (h - p) / d;
    t0 = Math.max(t0, Math.min(u, v)); t1 = Math.min(t1, Math.max(u, v));
    if (t0 > t1) return Infinity;
  }
  return clipSpanY(t0, t1, ay, dy, b.y, b.y + b.top);
}

// PROJECTILES: bullets stepped once per sim tick after contacts; the first thing on a tick's segment stops one.
class Projectiles {
  constructor(eco) {
    this.eco = eco;
    this.list = [];   // bullets in flight, oldest first
    this._q = [];
    this._hit = { t: Infinity, body: null, zone: null };   // cast's result: t along the segment (Infinity: clear), the body hit or null, its HIT_DAMAGE zone
  }

  clear() { this.list.length = 0; }

  // A bullet of `gun` from (x, y, z) along unit (dx, dy, dz); `hurts`: it costs a body health; `feeds`: a kill feeds the
  // shooter (armed people; the player harvests instead). It never hits its shooter.
  fire(shooter, x, y, z, dx, dy, dz, gun, hurts, feeds = false) {
    if (this.list.length >= BULLET_MAX) this.list.shift();
    const v = gun.muzzleMS;
    this.list.push({ x, y, z, vx: dx * v, vy: dy * v, vz: dz * v, gun, drag: bulletDragPerM(gun), shooter, hurts, feeds, firedAt: this.eco.time });
  }

  // Where a shot at t aims: the middle of its body's height (the avatar's position is already its body centre).
  static centreY(t) {
    if (t === ecosystem.avatar) return t.position.y;
    return t.position.y - t.footLift() * NPC_UNIT + t.bodyHeightM() / 2;
  }

  // Ground or water top at (x, z); -Infinity with no world.
  surfaceAt(x, z) {
    if (!providers.active) return -Infinity;
    providers.active.surface(x, z, _surf);
    return _surf.base;
  }

  // What segment a to b meets first: solids and building slabs, the ground and water, the car, live bodies (the avatar
  // while it is alive). `skip`: a body it passes through (the shooter's own).
  cast(ax, ay, az, bx, by, bz, out = this._hit, skip = null) {
    const eco = this.eco, dx = bx - ax, dy = by - ay, dz = bz - az;
    let best = segmentHit(ax, ay, az, bx, by, bz), body = null, zone = null;
    // ground and water tops, sampled; the crossing is placed between the samples
    const n = Math.max(1, Math.ceil(Math.hypot(dx, dy, dz) / BULLET_GROUND_STEP_M));
    let h0 = ay - this.surfaceAt(ax, az), t0 = 0;   // height over the surface at t0
    for (let k = 1; k <= n; k++) {
      const t = k / n;
      if (t0 >= best) break;
      const h1 = ay + dy * t - this.surfaceAt(ax + dx * t, az + dz * t);
      if (h1 < 0) { const th = h0 > 0 ? t0 + (t - t0) * h0 / (h0 - h1) : t0; if (th < best) best = th; break; }
      h0 = h1; t0 = t;
    }
    const box = eco.fallBox();
    if (box) best = Math.min(best, boxHit(ax, ay, az, dx, dy, dz, box));
    if (eco.animalGrid) {
      const now = eco.time, r = NPC_RADIUS;
      const reach = Math.hypot(dx, dz) / 2 + r + Math.sqrt(eco.drift2);   // grid positions can be a few ticks old
      const nq = eco.animalGrid.queryInto(this._q, ax + dx / 2, az + dz / 2, reach);
      for (let i = 0; i < nq; i++) {
        const a = this._q[i];
        if (!a.alive || a === skip) continue;
        const feet = a.position.y - a.footLift() * NPC_UNIT;
        const top = feet + (a.isDown(now) ? BULLET_DOWN_HIT_M : a.bodyHeightM());
        const t = cylinderHit(ax, ay, az, dx, dy, dz, a.position.x, a.position.z, r, feet, top);
        if (!(t < best)) continue;
        const z = this.zoneOf(a, ax, ay, az, dx, dy, dz, t, feet, now);
        if (z !== null) { best = t; body = a; zone = z; }
      }
    }
    // the avatar: a PLAYER_RADIUS column PLAYER_HEIGHT tall about its body centre, zoned by height as a person's
    const av = eco.avatar;
    if (av && av.alive && av !== skip) {
      const feet = av.position.y - PLAYER_HEIGHT / 2;
      const t = cylinderHit(ax, ay, az, dx, dy, dz, av.position.x, av.position.z, PLAYER_RADIUS, feet, feet + PLAYER_HEIGHT);
      if (t < best) {
        const Z = HIT_ZONES.human, share = (ay + dy * t - feet) / PLAYER_HEIGHT;
        best = t; body = av; zone = share < Z.limbBelow ? 'limb' : share >= Z.headAbove ? 'head' : 'body';
      }
    }
    out.t = best; out.body = body; out.zone = zone;
    return out;
  }

  // HIT ZONES: the HIT_DAMAGE zone a segment entering a's column at t strikes (HIT_ZONES), or null for a miss past the head.
  zoneOf(a, ax, ay, az, dx, dy, dz, t, feet, now) {
    if (a.isDown(now)) return 'body';
    const Z = HIT_ZONES[a.type], share = (ay + dy * t - feet) / a.bodyHeightM();   // height share up the body
    if (share < Z.limbBelow) return 'limb';
    const cx = a.position.x, cz = a.position.z, h2 = dx * dx + dz * dz;
    if (a.type === 'human') {
      // the line's least distance from the body's axis, metres (a straight-down shot: its point's)
      const off = h2 > 1e-12 ? Math.abs(dx * (cz - az) - dz * (cx - ax)) / Math.sqrt(h2) : Math.hypot(cx - ax, cz - az);
      const k = a.rigScale();   // metres per rig unit
      if (share >= Z.headAbove) return off <= Z.headR * k ? 'head' : null;
      return off <= Z.torsoR * k * (a.look ? a.look.shape.chest : 1) ? 'body' : 'limb';
    }
    // animals: the front of the column is the head
    const fwd = (ax + dx * t - cx) * Math.sin(a.facingAngle) + (az + dz * t - cz) * Math.cos(a.facingAngle);
    return fwd >= Z.headFwd * NPC_RADIUS ? 'head' : 'body';
  }

  // One tick: drag (implicit, dv/dt = -k v |v|) and gravity, then the move; a hit or an old or out-of-world bullet ends.
  step() {
    const L = this.list;
    if (L.length === 0) return;
    const eco = this.eco, dt = NPC_TICK_S, now = eco.time, hit = this._hit;
    for (let i = L.length - 1; i >= 0; i--) {
      const b = L[i];
      const keep = 1 / (1 + b.drag * Math.hypot(b.vx, b.vy, b.vz) * dt);
      b.vx *= keep; b.vy = b.vy * keep - BULLET_G * dt; b.vz *= keep;
      const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt, nz = b.z + b.vz * dt;
      this.cast(b.x, b.y, b.z, nx, ny, nz, hit, b.shooter);
      if (hit.t <= 1) { if (hit.body) this.strike(b, hit.body, hit.zone); L.splice(i, 1); continue; }
      b.x = nx; b.y = ny; b.z = nz;
      if (now - b.firedAt > b.gun.flightS || nx < eco.minX || nx > eco.maxX || nz < eco.minZ || nz > eco.maxZ) L.splice(i, 1);
    }
  }

  // A body hit: the bullet's impact pushes it against its hold (Ecosystem.impact); a hurting bullet costs its zone's share
  // of the body's base health (HIT_DAMAGE x startHealth), so toughness's extra max health takes more shots.
  strike(b, body, zone) {
    const hit = Ecosystem.impact(b.gun.bulletKg, body.bodyMassKg(), Math.hypot(b.vx, b.vy, b.vz));
    this.eco.applyHit(body, b.shooter, b.hurts ? HIT_DAMAGE[zone] * body.startHealth : 0, hit.pushN, b.feeds);
  }
}

// ECOSYSTEM: the Arena's World loop for every provider; stepped from frame().
export class Ecosystem {
  static CONTACT_DIST_SQ = 200 * NPC_UNIT * NPC_UNIT;
  static CONTACT_DIST = Math.sqrt(200) * NPC_UNIT;
  // The plant grid query for a bite: the bite reach (CONTACT_DIST) grown by a part in 1e9, so every plant the
  // CONTACT_DIST_SQ test can accept is in a visited cell despite rounding. Cells past it only held plants that test
  // rejects, and the visit order of the rest is unchanged, so the first plant bitten is the same.
  static PLANT_REACH_QUERY_R = this.CONTACT_DIST * (1 + 1e-9);
  static BUMP_DIST_SQ = NPC_BUMP_DIST * NPC_BUMP_DIST;   // BUMPING: touching distance, squared

  constructor() {
    this.animals = [];
    this.corpses = [];   // CORPSES: dead animals drawn lying, oldest first (addCorpse)
    this.falls = [];     // FALLS: bodies being simulated, living and dead (beginFall)
    this.ragdolls = false;      // FALLS: the collision mode has ragdolls (setRagdolls, from main's applyCollision)
    this.fallBox = () => null;  // FALLS: the car's box this tick, or null (8b fills it)
    this._fallPools = {};       // FALLS: spare bodies by type
    this._fallWorld = new THREE.Vector3();
    this._fallQuat = new THREE.Quaternion();
    this.plants = [];
    this.ticks = 0;
    this.ready = false;
    this.shownPop = -1;
    this.minX = 0; this.maxX = 0; this.minZ = 0; this.maxZ = 0;
    this.wraps = false;

    this.animalGrid = null;
    this.plantGrid = null;
    // Plants for vision queries; rebuilt with plantGrid.
    this.plantSight = null;
    // Water points for vision queries.
    this.waterSight = null;
    this.aliveById = new Int32Array(NPC_KIND_COUNT);             // per kind: live count
    this.canHuntById = new Uint8Array(NPC_KIND_COUNT);           // per kind: 1 while its prey lives
    this.fastestHunterMSById = new Float64Array(NPC_KIND_COUNT); // per kind: fastest live hunter, m/s
    this.night = false;   // sun below NIGHT_SUN_ALT_DEG: night hunts on
    this.afterContacts = [];   // fn(dt) after each tick's contacts
    this.avatar = null;        // the player's avatar (the game registers)
    this.brainlessOn = false;  // brainless people (provider.opts.brainless, Zombies mode): every person outside the zombie and armed slices brainless and unarmed
    this.armedOn = false;      // the mode's armed people (provider.opts.armed, PLAY_MODES): RULE_PEOPLE.armedShare of people armed and brainless, at spawn and birth
    this.seedingZombies = false; // true only while the world's first people spawn in Zombies mode: RULE_PEOPLE.zombieShare start as zombies

    this._qPlant = [];
    this._qWater = [];
    this._qBox = [];
    this._qSeen = [];         // locate: animals in the sight box
    this._qSeenPlants = [];   // locate: plants in the sight box
    this._plantAdds = [];
    this._plantDrops = [];
    this._animalGridDrops = [];    // removed animals still in the grid
    this._dead = [];               // compactLive's scratch: the entries it took out, in list order
    this.plantsDied = false;       // a plant died, so removal runs
    this.drift2 = 0;
    this.contact = null;
    this._contactR = Ecosystem.CONTACT_DIST;
    this._bumpVel = { x: 0, z: 0 };   // handleCollisions' scratch for takeBumpVelocity
    this.projectiles = new Projectiles(this);   // bullets in flight, stepped after contacts
  }

  // SIM CLOCK: sim seconds since init; pauses with the sim.
  get time() { return this.ticks * NPC_TICK_S; }

  // Keep a coordinate in the world: torus wrap or clamp.
  fitX(x) {
    if (this.wraps) return this.minX + tools.wrap(x - this.minX, this.maxX - this.minX);
    return x < this.minX ? this.minX : x > this.maxX ? this.maxX : x;
  }

  fitZ(z) {
    if (this.wraps) return this.minZ + tools.wrap(z - this.minZ, this.maxZ - this.minZ);
    return z < this.minZ ? this.minZ : z > this.maxZ ? this.maxZ : z;
  }

  clear() {
    this.animals.length = 0;
    this.corpses.length = 0;
    this.dropFalls();
    this.projectiles.clear();
    this.plants.length = 0;
    this._plantAdds.length = 0;
    this._plantDrops.length = 0;
    this.plantsDied = false;
    this.ready = false;
  }

  // true once per population change
  populationChanged() {
    if (this.animals.length === this.shownPop) return false;
    this.shownPop = this.animals.length;
    return true;
  }

  // Spatial indexes, then the provider's population.
  initialize(provider) {
    this.animals.length = 0;
    this.corpses.length = 0;
    this.dropFalls();
    this.plants.length = 0;
    this._plantAdds.length = 0;
    this._plantDrops.length = 0;
    this.plantsDied = false;
    this.ticks = 0;
    this.projectiles.clear();
    this._animalGridDrops.length = 0;
    const b = provider.bounds;
    this.minX = b.minX; this.maxX = b.maxX;
    this.minZ = b.minZ; this.maxZ = b.maxZ;
    collision.openBounds = { minX: b.minX, maxX: b.maxX, minZ: b.minZ, maxZ: b.maxZ };
    this.wraps = provider.wraps;

    const spanX = b.maxX - b.minX + 1, spanZ = b.maxZ - b.minZ + 1;
    this.animalGrid = new SpatialGrid(spanX, spanZ, 160 * NPC_UNIT);
    this.plantGrid = new SpatialGrid(spanX, spanZ, 30 * NPC_UNIT);
    this.contact = new ContactGrid(NPC_CONTACT_CELL);
    this.plantSight = new SpatialGrid(spanX, spanZ, PLANT_SIGHT_CELL);
    this.waterSight = new SpatialGrid(spanX, spanZ, WATER_SIGHT_CELL);
    for (const w of provider.waterSources()) this.waterSight.insert({ position: { x: w[0], y: w[2], z: w[1] } });
    foodBoxes.buildSight(spanX, spanZ);
    this.brainlessOn = provider.opts?.brainless === true;   // read by Animal's constructor, at spawn and birth
    this.armedOn = provider.opts?.armed === true;           // read by Animal's constructor, at spawn and birth
    const outbreak = !provider.drive && provider.opts?.zombies === true;   // Zombies mode; the intro drives its own walkers

    occ.build();
    const plan = provider.population();
    for (const g of plan) if (g.type === 'plant') for (let i = 0; i < g.count; i++) this.spawnPlant(g.src);
    this.seedingZombies = outbreak;   // the zombie slice is rolled only for these first people, never at birth
    for (const g of plan) if (g.type !== 'plant') this.spawn(g.type, g.count, g.src);
    this.seedingZombies = false;
    if (outbreak) this.startOutbreak();
    this.ready = true;
    this.shownPop = -1;
  }

  // ZOMBIES: as the world starts, the zombie slice the Animal constructor rolled (seedZombie, RULE_PEOPLE.zombieShare of
  // all people) turns.
  startOutbreak() {
    for (const a of this.animals) if (a.seedZombie && !a.zombie) a.turn();
  }

  spawnPlant(src) {
    const s = src.spawnPoint('plant');
    if (!s) return;
    const p = new Plant([s[0], 0, s[1]]);
    this.plants.push(p);
    p._sightKey = this.plantSight.insert(p);
    this._plantAdds.push(p);
  }

  syncPlantGrids() {
    const drops = this._plantDrops, adds = this._plantAdds;
    for (let i = 0; i < drops.length; i++) {
      const p = drops[i];
      if (p._gridKey >= 0) { this.plantGrid.remove(p, p._gridKey); p._gridKey = -1; }
      if (p._sightKey >= 0) { this.plantSight.remove(p, p._sightKey); p._sightKey = -1; }
    }
    for (let i = 0; i < adds.length; i++) {
      const p = adds[i];
      if (p.alive && p._sightKey >= 0) p._gridKey = this.plantGrid.insert(p);
    }
    drops.length = 0;
    adds.length = 0;
  }

  // Places `count` of `type` NPC_SPAWN_GAP apart; returns how many.
  spawn(type, count, src) {
    if (count <= 0) return 0;
    const cell = NPC_SPAWN_GAP;
    const taken = new Map();
    let gap = NPC_SPAWN_GAP, placed = 0;
    const maxTries = count * 80;
    for (let tries = 1; placed < count && tries <= maxTries; tries++) {
      if (tries % (count * 20) === 0) gap *= 0.5;
      const p = src.spawnPoint(type);
      if (!p) continue;
      const [x, z] = p;
      if (!isOpen(x, z)) continue;
      const ci = Math.floor(x / cell), cj = Math.floor(z / cell);
      let crowded = false;
      for (let di = -1; di <= 1 && !crowded; di++) {
        for (let dj = -1; dj <= 1 && !crowded; dj++) {
          const list = taken.get(cellKey(ci + di, cj + dj));
          if (!list) continue;
          for (let i = 0; i < list.length; i += 2) {
            const dx = list[i] - x, dz = list[i + 1] - z;
            if (dx * dx + dz * dz < gap * gap) { crowded = true; break; }
          }
        }
      }
      if (crowded) continue;

      const key = cellKey(ci, cj);
      let list = taken.get(key);
      if (!list) { list = []; taken.set(key, list); }
      list.push(x, z);
      placed++;

      const a = new Animal([x, 0, z], type);
      a.heading = a.targetHeading = a.facingAngle = Math.random() * Animal.TWO_PI;
      a.position.y = surfaceY(x, z) + a.footLift() * NPC_UNIT;
      a.freeX = x; a.freeZ = z;
      a.home = src;
      this.animals.push(a);
    }
    return placed;
  }

  tryMate(a, px, pz) {
    if (a.sex !== 'male') return;
    const cg = this.contact, items = cg.items, start = cg.start;
    const nh = cg.cellsFor(px, pz, this._contactR), hs = cg.hs;
    for (let q = 0; q < nh; q++) for (let i = start[hs[q]], iEnd = start[hs[q] + 1]; i < iEnd; i++) {
      const other = items[i];
      if (other !== a && other.alive && other.kindId === a.kindId &&
        other.sex === 'female' && other.lookForMate &&
        tools.distSq(px, pz, other.position.x, other.position.z) < Ecosystem.CONTACT_DIST_SQ) {
        const child = a.mate(other);
        // City: a child in or through a wall is born at the mother's spot.
        const cp = child.position, mp = other.position;
        if (occ.blockedAt(cp.x, cp.z) ||
          shellAt(cp.x, cp.z) !== shellAt(mp.x, mp.z)) {
          cp.x = mp.x; cp.z = mp.z;
        }
        cp.x = this.fitX(cp.x); cp.z = this.fitZ(cp.z);
        child.freeX = cp.x; child.freeZ = cp.z;
        this.animals.push(child);
        return;
      }
    }
  }

  // Contact: hunters kill, all mate and drink, grazers eat plants.
  handleCollisions() {
    if (this.ticks % 3 === 0) this.syncPlantGrids();
    // Candidates from a grid up to 2 ticks old.
    this._contactR = Ecosystem.CONTACT_DIST + Math.sqrt(this.drift2);
    const cg = this.contact, items = cg.items, start = cg.start;
    const now = this.time;

    for (const a of this.animals) {
      if (!a.alive) continue;
      const px = a.position.x, pz = a.position.z;

      const down = a.isDown(now);
      // one neighbour pass for hunting and bumping; hunts is 0 when down or preyless
      // an armed person (RULE_PEOPLE) attacks only by shooting (shootStep), so it strikes nothing on contact
      const hunts = !down && a.gun === null && this.canHuntById[a.kindId] ? HUNTS_MASK[a.kindId] : 0;
      // BUMPING: this tick's velocity (vel), as a was when its pass began. Taken on first use, before a's first strike
      // or bump: until then the pass only reads, so it is the same as taking it here, and a pass with neither (most
      // animals) skips groundSpeed. velocityTaken: vel holds a's.
      const vel = this._bumpVel;
      let velocityTaken = false;
      const nh = cg.cellsFor(px, pz, this._contactR), hs = cg.hs;
      near: for (let q = 0; q < nh; q++) for (let i = start[hs[q]], iEnd = start[hs[q] + 1]; i < iEnd; i++) {
        const other = items[i];
        if (other === a || !other.alive) continue;
        const dx = other.position.x - px, dz = other.position.z - pz, d2 = dx * dx + dz * dz;
        if ((hunts & (1 << other.kindId)) !== 0 && d2 < Ecosystem.CONTACT_DIST_SQ) {
          // PACK STRENGTH: strike only what the pack can take
          if (a.nextAttackAt <= now && a.mayAttack(other)) {
            // before the strike, which turns a and holds it
            if (!velocityTaken) { this.takeBumpVelocity(a, now, vel); velocityTaken = true; }
            // one hit per cooldown, on the first prey in reach
            this.contactHit(a, other);
          }
          if (!a.alive) break near;
        }
        if (other.alive && d2 < Ecosystem.BUMP_DIST_SQ) {
          if (!velocityTaken) { this.takeBumpVelocity(a, now, vel); velocityTaken = true; }
          this.bump(a, other, dx, dz, d2, vel.x, vel.z);
        }
      }
      if (!a.alive) continue;
      if (!down && a.lookForMate) this.tryMate(a, px, pz);

      const canEat = a.noEatUntil <= now;
      const nPlant = canEat && a.kindSpec.grazes && a.nextBiteAt <= now ? this.plantGrid.queryInto(this._qPlant, px, pz, Ecosystem.PLANT_REACH_QUERY_R) : 0;
      for (let i = 0; i < nPlant; i++) {
        const plant = this._qPlant[i];
        if (plant.alive &&
          tools.distSq(px, pz, plant.position.x, plant.position.z) < Ecosystem.CONTACT_DIST_SQ) {
          // one bite per cooldown
          a.eatPlant(plant);
          a.nextBiteAt = now + NPC_BITE_COOLDOWN_S;
          break;
        }
      }

      const crate = canEat && a.kindSpec.crates === true ? foodBoxes.touching(this._qBox, px, a.position.y, pz) : null;
      if (crate) { a.eatBox(); foodBoxes.eat(crate); }

      if (surfaceFor(a, px, pz) < 0) {
        a.drinkWater();
      }
    }
  }

  // CONTACT HITS: a strikes b once per cooldown; fightHit if b hunts a, else a share of b's base health x a's strength.
  contactHit(a, b) {
    const now = this.time, mutual = (HUNTS_MASK[b.kindId] & (1 << a.kindId)) !== 0;   // true: b fights back in kind
    a.strike(b);
    if (mutual) this.fightHit(a, b);
    else this.applyHit(b, a, b.startHealth * NPC_ATTACK_DAMAGE_PER_S * NPC_ATTACK_COOLDOWN_S * a.strength);
    if (a.zombie && b.alive && Math.random() < ZOMBIES.infectChance) b.infect(now);
    a.nextAttackAt = now + NPC_ATTACK_COOLDOWN_S;
  }

  // BUMPING: a's velocity this tick into out { x, z }, m/s: groundSpeed along its heading
  takeBumpVelocity(a, now, out) {
    const speed = a.groundSpeed(now);
    a.headingDir();
    out.x = a._dirSin * speed; out.z = a._dirCos * speed;
  }

  // A strikes b: damage scales with a's strength, fighting mass x health (as NPC_FIGHT_REF_STRENGTH), relative to the
  // reference fighter's. Nothing about b changes it.
  fightHit(a, b) {
    // health enters as its share of max times the base, so toughness alone adds no damage; the strength gene scales it
    const strength = a.fightMassKg() * Math.max(0, a.health) / a.maxHealth * a.startHealth * a.strength;
    this.applyHit(b, a, NPC_FIGHT_DAMAGE_PER_S * NPC_ATTACK_COOLDOWN_S * strength / NPC_FIGHT_REF_STRENGTH);
  }

  // BUMPING, a's side of a pair: b moves half the overlap away, and a's momentum pushes it against its hold.
  bump(a, b, dx, dz, d2, vx, vz) {
    const d = Math.sqrt(d2);
    if (d < 1e-6) return;   // same spot: no direction
    const nx = dx / d, nz = dz / d, half = (NPC_BUMP_DIST - d) / 2;
    const bx = this.fitX(b.position.x + nx * half), bz = this.fitZ(b.position.z + nz * half);
    if (!occ.blockedAt(bx, bz)) this.shove(b, bx, bz);
    const closing = vx * nx + vz * nz;   // m/s a moves toward b
    if (closing > 0) this.applyHit(b, a, 0, Ecosystem.bumpForceN(a.bodyMassKg(), closing));
  }
  // BUMPING: push in newtons, momentum stopped over NPC_BUMP_CONTACT_S
  static bumpForceN(massKg, closingMS) { return massKg * closingMS / NPC_BUMP_CONTACT_S; }

  // BUMP IMPACTS: true on a contact's first touching tick with `body` (not touched the tick before). Later touching
  // ticks are the pair moving together, with no new impact.
  freshContact(body) {
    const fresh = body.contactTick < this.ticks - 1;
    body.contactTick = this.ticks;
    return fresh;
  }
  // BUMP IMPACTS: a pair of massAKg and massBKg closing at closingMS. Fills `out`: impulseNs, the same on both bodies
  // (Newton's third law); pushN, that impulse over NPC_BUMP_CONTACT_S; energyJ, the closing motion's energy; damage, body
  // health lost by each of the pair at BUMP_HEALTH_PER_J.
  static impact(massAKg, massBKg, closingMS, out = Ecosystem._impact) {
    const reducedKg = massAKg * massBKg / (massAKg + massBKg);
    out.impulseNs = reducedKg * closingMS * (1 + BUMP_RESTITUTION);
    out.pushN = out.impulseNs / NPC_BUMP_CONTACT_S;
    out.energyJ = reducedKg * closingMS * closingMS / 2;
    out.damage = Ecosystem.impactDamage(out.energyJ, BUMP_HEALTH_PER_J);
    return out;
  }
  static _impact = { impulseNs: 0, pushN: 0, energyJ: 0, damage: 0 };
  // BUMP IMPACTS: health lost at healthPerJ past BUMP_SAFE_J
  static impactDamage(energyJ, healthPerJ) { return Math.max(0, energyJ - BUMP_SAFE_J) * healthPerJ; }

  // KNOCKDOWNS: every hit and bump comes here. Damage first (a kill feeds the attacker when `feeds`), then pushN
  // against the hold (0 when not braced()). Past it the body falls, away from the push if braced, over toward it if
  // airborne, longer the further past.
  applyHit(target, attacker, damage, pushN = Ecosystem.hitForceN(attacker), feeds = true) {
    if (damage > 0) target.takeHit(attacker, damage, feeds);
    // CORPSES: a killed animal has no hold; it falls from the hit, and addCorpse keeps it down
    if (target instanceof Animal && !target.alive) { if (!target.isDown(this.time)) this.startFall(target, attacker, true, pushN, 0); return; }
    if (!target.knockable()) return;   // dead, or the player out of play or sheltered
    const bracedHoldN = Ecosystem.holdForceN(target);        // hold with feet planted
    const braced = target.braced();   // true: feet planted, it holds and falls away; false: airborne, no hold, legs swept
    const holdN = braced ? bracedHoldN : 0;
    if (!(pushN > holdN)) return;
    const now = this.time;
    // down time scales with the push past the braced hold
    const excess = Math.max(0, pushN / Math.max(bracedHoldN, 1e-9) - 1);
    const downS = Math.min(NPC_DOWN_MAX_S, NPC_DOWN_MIN_S + NPC_DOWN_S_PER_EXCESS * excess);
    if (!target.isDown(now)) this.startFall(target, attacker, braced, pushN, holdN);
    target.downUntil = Math.max(target.downUntil, now + downS);
  }
  // KNOCKDOWNS: a fall starting now. Braced, it topples away from the attacker (backward when facing it); airborne, the
  // push takes its legs, so the upper body pitches over toward the attacker (head first when facing it). The push past
  // the hold is its launch speed.
  startFall(target, attacker, braced, pushN, holdN) {
    target.downAt = this.time;
    const away = braced ? 1 : -1;
    const dx = (target.position.x - attacker.position.x) * away, dz = (target.position.z - attacker.position.z) * away;
    target.downYaw = dx !== 0 || dz !== 0 ? wrapAngle(Math.atan2(dx, dz)) : target.facingAngle + (braced ? Math.PI : 0);
    target.downDV = Math.max(0, pushN - holdN) * NPC_BUMP_CONTACT_S / target.bodyMassKg();
    this.beginFall(target);
  }

  // CORPSES: a dead animal lies where it fell, drawn only, for CORPSE_S. One already falling (a fatal hit) keeps its
  // fall; any other death collapses forward where it stands. The oldest past CORPSE_MAX goes.
  addCorpse(a) {
    const now = this.time;
    if (!a.isDown(now)) { a.downAt = now; a.downYaw = a.facingAngle; a.downDV = 0; this.beginFall(a); }
    a.downUntil = Infinity;   // never rises
    a.moving = false; a.playing = null;
    a.diedAt = now;
    a.corpseUntil = now + CORPSE_S;
    this.corpses.push(a);
    // the oldest pushed out is no longer shown, so its fall ends on the next stepFalls as a removed corpse's does
    // (left at its CORPSE_S time, it went on stepping undrawn until then)
    if (this.corpses.length > CORPSE_MAX) this.corpses.shift().corpseUntil = now;
  }
  // CARRION, one tick: each body is eaten whole (feedOn) by the first hungry, standing animal touching it whose species
  // eats that kind (CARRION_MASK); an eaten body is gone.
  eatCorpses() {
    const c = this.corpses, cg = this.contact, items = cg.items, start = cg.start, now = this.time;
    for (let i = c.length - 1; i >= 0; i--) {
      const body = c[i], bit = 1 << body.kindId, px = body.position.x, pz = body.position.z;
      const nh = cg.cellsFor(px, pz, this._contactR), hs = cg.hs;
      eat: for (let q = 0; q < nh; q++) for (let k = start[hs[q]], kEnd = start[hs[q] + 1]; k < kEnd; k++) {
        const a = items[k];
        if (!a.alive || (CARRION_MASK[a.kindId] & bit) === 0 || a.foodNeed <= 0 || a.isDown(now) || a.noEatUntil > now) continue;
        if (tools.distSq(px, pz, a.position.x, a.position.z) >= Ecosystem.CONTACT_DIST_SQ) continue;
        a.feedOn(body);
        this.removeCorpse(body);
        break eat;
      }
    }
  }
  // CORPSES: a body taken away now (eaten, harvested); its fall ends on the next stepFalls.
  removeCorpse(body) {
    const i = this.corpses.indexOf(body);
    if (i < 0) return;
    body.corpseUntil = this.time;
    this.corpses.splice(i, 1);
  }
  // CORPSES: drop the ones past their time (oldest first)
  expireCorpses() {
    const c = this.corpses, now = this.time;
    let n = 0;
    while (n < c.length && c[n].corpseUntil <= now) n++;
    if (n > 0) c.splice(0, n);
  }
  // hit push: fighting mass x NPC_HIT_ACCEL_MS2 x condition x strength gene
  static hitForceN(attacker) { return attacker.fightMassKg() * NPC_HIT_ACCEL_MS2 * attacker.condition() * attacker.strength; }
  // hold: fighting mass x NPC_HOLD_ACCEL_MS2 x condition
  static holdForceN(target) { return target.fightMassKg() * NPC_HOLD_ACCEL_MS2 * target.condition(); }

  // Move b to (x, z); a body in a fall moves whole with it.
  shove(b, x, z) {
    if (b.fall) b.fall.body.translate(x - b.position.x, z - b.position.z);
    b.position.x = x; b.position.z = z;
  }

  // FALLS: ragdolls on or off (main's applyCollision); off ends every fall where it is.
  setRagdolls(on) {
    this.ragdolls = on;
    if (!on) this.dropFalls();
  }

  // FALLS: an animal starting to fall gets its body, from its standing pose, launched by the hit (downYaw, downDV).
  // Ragdolls off, the player's avatar (the renderer's) and species without a fall rig keep the lying pose.
  beginFall(a) {
    if (!this.ragdolls || !(a instanceof Animal) || a.fall) return;
    const human = a.type === 'human';   // true: a HumanFall, false: a BoxFall from the type's registered rig
    const rig = human ? null : fallRigs[a.type];
    if (!human && !rig) return;
    const f = (this._fallPools[a.type] ??= []).pop() ?? (human ? new HumanFall() : new BoxFall(rig));
    const kp = a.rigScale();
    const world = this._fallWorld.set(a.position.x, a.originY(), a.position.z);
    const quat = this._fallQuat.setFromAxisAngle(Ecosystem.Y_AXIS, a.facingAngle);
    f.start(a, world, quat, kp, world.y - SPECIES[a.type].lift * kp);
    f.owner = a; f.type = a.type; f.stillS = 0; f.asleep = false;
    a.fall = f;
    this.falls.push(f);
  }
  static Y_AXIS = new THREE.Vector3(0, 1, 0);

  // FALLS, one tick: every body steps (gravity, links, ground, the car's box), kept out of walls and in the world, and
  // its animal is placed where it lies. A body still for FALL_SETTLE_S sleeps until the car's box reaches it. A rising
  // animal's body holds while it gets up (the renderer blends it to standing); a risen animal or a gone corpse ends it.
  stepFalls() {
    const fs = this.falls;
    if (fs.length === 0) return;
    const now = this.time, box = this.fallBox();
    const stillSq = (FALL_SETTLE_MS * NPC_TICK_S) * (FALL_SETTLE_MS * NPC_TICK_S);   // a still step's largest move, squared
    for (let i = fs.length - 1; i >= 0; i--) {
      const f = fs[i], a = f.owner, b = f.body;
      const ended = a.alive ? now >= a.downUntil : a.corpseUntil <= now;   // true: risen, or no longer a shown corpse
      if (ended) { this.endFall(i); continue; }
      if (now >= a.downUntil - NPC_GETUP_S) continue;   // rising where it lies (a corpse's downUntil is Infinity)
      if (f.asleep && box && b.nearBox(box)) { f.asleep = false; f.stillS = 0; }
      if (!f.asleep) {
        b.anchorCentre();
        const fromX = b.cx, fromZ = b.cz;
        b.step(box);
        this.keepFallIn(b, fromX, fromZ);
        f.stillS = b.maxStepSq() < stillSq ? f.stillS + NPC_TICK_S : 0;
        f.asleep = f.stillS >= FALL_SETTLE_S;
      }
      this.placeOnFall(a, b);
    }
  }

  // FALLS: the body kept in the world (wrap or clamp moves it whole) and out of walls, sliding along them like collide:
  // the blocked axis of this step's anchor move is undone and its speed stopped. (fromX, fromZ): the anchors before.
  keepFallIn(b, fromX, fromZ) {
    b.anchorCentre();
    let cx = b.cx, cz = b.cz;
    const fx = this.fitX(cx), fz = this.fitZ(cz);
    if (fx !== cx || fz !== cz) { b.translate(fx - cx, fz - cz); fromX += fx - cx; fromZ += fz - cz; cx = fx; cz = fz; }
    if (!occ.blockedAt(cx, cz)) return;
    if (!occ.blockedAt(cx, fromZ)) { b.translate(0, fromZ - cz); b.stopAxis(false, true); }
    else if (!occ.blockedAt(fromX, cz)) { b.translate(fromX - cx, 0); b.stopAxis(true, false); }
    else { b.translate(fromX - cx, fromZ - cz); b.stopAxis(true, true); }
    b.fitBounds();
  }

  // FALLS: the animal where its body lies: x, z the anchors' centre (hips for people, body for box rigs), its centre
  // height its lift over the body's lowest point (the ground, or the car's roof).
  placeOnFall(a, b) {
    b.anchorCentre();
    a.position.x = b.cx; a.position.z = b.cz;
    a.position.y = b.lowestY() + a.footLift() * NPC_UNIT;
    a.freeX = b.cx; a.freeZ = b.cz;
  }

  // FALLS: fall i ended; its body back to the pool.
  endFall(i) {
    const f = this.falls[i];
    f.owner.fall = null;
    f.owner = null;
    this._fallPools[f.type].push(f);
    this.falls.splice(i, 1);
  }

  // FALLS: every fall ended where it is (a new or cleared world, ragdolls off).
  dropFalls() {
    for (let i = this.falls.length - 1; i >= 0; i--) this.endFall(i);
  }

  // Occupancy-grid wall check: a blocked step slides or is undone.
  collide(a) {
    if (!a.moving || !a.brain) return;
    const p = a.position;
    if (occ.blockedAt(p.x, p.z)) {
      if (!occ.blockedAt(p.x, a.freeZ)) p.z = a.freeZ;
      else if (!occ.blockedAt(a.freeX, p.z)) p.x = a.freeX;
      else { p.x = a.freeX; p.z = a.freeZ; }
    }
    a.freeX = p.x; a.freeZ = p.z;
  }

  step(dt) {
    if (!this.ready || this.animals.length === 0) return false;
    // a provider that drives its own NPCs replaces the sim
    if (providers.active && providers.active.drive) return providers.active.drive(this, dt);
    const now = this.time;
    this.night = simSky.sunAltDeg < NIGHT_SUN_ALT_DEG;

    // Incremental grid sync every 3 ticks.
    if (this.ticks % 3 === 0) {
      const g = this.animalGrid, drops = this._animalGridDrops;
      for (let i = 0; i < drops.length; i++) {
        const d = drops[i];
        if (d._gk >= 0) { g.remove(d, d._gk); d._gk = -1; }
      }
      drops.length = 0;
      for (const a of this.animals) {
        if (!a.alive) {
          if (a._gk >= 0) { g.remove(a, a._gk); a._gk = -1; }
          continue;
        }
        const k = g._cell(a.position.x, a.position.z);
        if (k !== a._gk) {
          if (a._gk >= 0) g.remove(a, a._gk);
          g.place(a, k);
          a._gk = k;
        }
        a._fx = a.position.x; a._fz = a.position.z;
      }
      this.contact.rebuild(this.animals);
      this.drift2 = 0;
    }

    const alive = this.aliveById, fastest = this.fastestHunterMSById;
    alive.fill(0); fastest.fill(0);
    // PERF PROBE 'animals': the whole per-animal loop (Animal.update, collide and the bookkeeping beside them)
    const tAnimals = perfProbe.t();
    for (let ai = 0; ai < this.animals.length; ai++) {
      const a = this.animals[ai];
      if (a.alive) {
        a.update(now, this.animalGrid);
        if (a.alive) {
          this.collide(a);
          const fx = a.position.x - a._fx, fz = a.position.z - a._fz, f2 = fx * fx + fz * fz;
          if (f2 > this.drift2) this.drift2 = f2;
          alive[a.kindId]++;
          const ms = a.moveSpeed() * NPC_UNIT, prey = HUNTS_LIST[a.kindId];
          for (let k = 0; k < prey.length; k++) if (ms > fastest[prey[k]]) fastest[prey[k]] = ms;
        }
      }
    }
    for (let t = 0; t < NPC_KIND_COUNT; t++) {
      const prey = HUNTS_LIST[t];
      let any = 0;
      for (let k = 0; k < prey.length; k++) if (alive[prey[k]]) { any = 1; break; }
      this.canHuntById[t] = any;
    }
    perfProbe.add('animals', tAnimals);

    // skip the retry pass when nothing waits
    if (plantView.pending) {
      plantView.pending = false;
      for (const p of this.plants) {
        if (p.alive) p.update();
      }
    }

    const tCollisions = perfProbe.t();
    this.handleCollisions();
    perfProbe.add('collisions', tCollisions);
    for (const f of this.afterContacts) f(dt);
    this.projectiles.step();   // before deaths are counted, so a shot kill leaves its corpse this tick
    this.eatCorpses();

    this.expireCorpses();
    // the dead handled last to first, as the per-death splice loop this replaces did
    const deadAnimals = this.compactLive(this.animals);
    for (let i = deadAnimals.length - 1; i >= 0; i--) {
      const a = deadAnimals[i];
      a.remove();
      this._animalGridDrops.push(a);
      // CORPSES: died of health loss (not eaten whole or taken out of the world)
      if (a.health <= Animal.DEATH_HEALTH) this.addCorpse(a);
    }
    // FALLS: after addCorpse, so an animal that died falling keeps its body as a corpse
    this.stepFalls();
    if (this.plantsDied) {
      this.plantsDied = false;
      const deadPlants = this.compactLive(this.plants);
      for (let i = deadPlants.length - 1; i >= 0; i--) {
        deadPlants[i].remove();
        this._plantDrops.push(deadPlants[i]);
      }
    }

    providers.active.regrow(this);

    return true;
  }

  // Takes the dead out of `list` in one pass, keeping the living in order (one O(n) pass where a splice per death was
  // O(n) each); returns the removed entries in list order, in a scratch array reused by the next call.
  compactLive(list) {
    const dead = this._dead;
    dead.length = 0;
    let n = 0;
    for (let i = 0; i < list.length; i++) {
      const e = list[i];
      if (e.alive) list[n++] = e;
      else dead.push(e);
    }
    list.length = n;
    return dead;
  }

  // The clock advances once main has drawn this tick.
  endTick() { this.ticks++; }
}
export const ecosystem = new Ecosystem();

// GAME SKY: own clock and weather; an Observer preset overrides it.
export const simSky = {
  running: false,              // a world is in play
  DAY_S,                       // real seconds per game day
  SPAN: [60, 180],             // seconds each weather lasts
  STEP_S: 0.25,                // sky redraw interval
  KINDS: ['Clear', 'Cloudy', 'Overcast', 'Fog', 'Rain', 'Snow', 'Storm'],
  hour: 15, day: 0, kind: 'Rain', timer: 0, acc: 0, lastNow: 0, shownMinute: -1,
  // FREEZE (main sets them: the Freeze chips, Observer only); people, animals and plants always go on
  clockFrozen: false,     // the hour (and so the sun) holds
  weatherFrozen: false,   // the game's weather holds (no change when its span runs out)

  site: null,   // the world's { lat, lon, offset }
  sunAltDeg: 90,   // drawn sun altitude, degrees
  onSkyStep: null, onMinute: null,   // sky redraw and HUD minute hooks
  get on() { return this.running; },

  start() {
    this.running = true;
    this.hour = GAME_START_HOUR;
    this.day = 0;   // midnights since load (HUD day)
    this.startWeather(GAME_START_SKY);
    this.acc = 0;
    this.lastNow = 0;
    this.shownMinute = -1;
  },
  stop() { this.running = false; },

  // `kind` for a random span
  startWeather(kind) {
    this.kind = kind;
    this.timer = this.SPAN[0] + Math.random() * (this.SPAN[1] - this.SPAN[0]);
  },
  // Any weather, for a random span (each time the last one runs out)
  randomizeWeather() {
    this.startWeather(this.KINDS[Math.floor(Math.random() * this.KINDS.length)]);
  },
  // The clock to `hour` (a time chip); it keeps running from there unless clockFrozen.
  setHour(hour) {
    this.hour = hour;
    this.shownMinute = -1;
  },

  conditions() { return SKIES[this.kind]; },

  // real time, so a slow frame rate cannot stretch the day
  update(now) {
    if (!this.running || document.hidden) { this.lastNow = 0; return; }
    const dt = this.lastNow ? Math.min(Math.max((now - this.lastNow) / 1000, 0), 5) : 0;
    this.lastNow = now;
    if (!this.clockFrozen) {
      const hours = this.hour + dt * 24 / this.DAY_S;
      this.day += Math.floor(hours / 24);
      this.hour = hours % 24;
    }
    if (!this.weatherFrozen) this.timer -= dt;
    let changed = false;
    if (this.timer <= 0) {
      this.randomizeWeather();
      changed = true;
    }
    this.acc += dt;
    if (changed || this.acc >= this.STEP_S) {
      this.acc = 0;
      this.onSkyStep();
    }
    // the HUD clock reads game minutes
    const minute = Math.floor(this.hour * 60);
    if (changed || minute !== this.shownMinute) { this.shownMinute = minute; this.onMinute(); }
  }
};

export function presetHour(name) { return FALLBACK_HOURS[name]; }